<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog - Batik Joyodipo</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            dark: '#3b2314',
                            brown: '#5c3a21',
                            light: '#fdfbf7',
                            accent: '#d4af37',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#fcfaf5] text-stone-800 font-sans antialiased">

    <!-- TOP NAVIGATION BAR -->
    <header class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="text-xl font-bold tracking-widest text-[#3b2314]">BATIK JOYODIPO</span>
            </div>

            <!-- Sub Navigation Menu -->
            <nav class="hidden md:flex space-x-6 text-xs font-semibold text-stone-600">
                <a href="index.php" class="hover:text-[#5c3a21]">BERANDA</a>
                <a href="katalog.php" class="text-[#5c3a21] border-b-2 border-[#5c3a21] pb-1">KATALOG</a>
                <a href="#" class="hover:text-[#5c3a21]">BATIK TULIS</a>
                <a href="#" class="hover:text-[#5c3a21]">BATIK CAP</a>
                <a href="#" class="hover:text-[#5c3a21]">BAHAN HANDPRINT</a>
                <a href="#" class="hover:text-[#5c3a21]">PAKAIAN WANITA</a>
                <a href="#" class="hover:text-[#5c3a21]">PAKAIAN PRIA</a>
                <a href="#" class="hover:text-[#5c3a21]">SARIMBIT</a>
            </nav>

            <div class="flex items-center space-x-4">
                <span class="text-sm cursor-pointer">🔍</span>
                <a href="wishlist.php" class="text-sm cursor-pointer" title="Mahakarya Disukai">❤️</a>
                <span class="text-sm cursor-pointer">🛒</span>
                <span class="bg-[#25D366] text-white text-xs px-3 py-1.5 rounded-full font-medium flex items-center gap-1">💬 WhatsApp CS</span>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <!-- BREADCRUMB & TITLE -->
        <div class="border-b border-stone-200 pb-6">
            <p class="text-xs uppercase tracking-widest text-stone-500 mb-1">Beranda > Katalog Mahakarya Wastra</p>
            <h1 class="text-3xl font-serif font-bold text-[#3b2314]">Katalog Batik Joyodipo</h1>
            <p class="text-stone-600 text-sm mt-2 max-w-3xl">
                Eksplorasi kurasi busana batik otentik hasil karya pengrajin maestro dari Surakarta, Yogyakarta, Pekalongan, dan Cirebon. Menyajikan batik tulis halus, cap tembaga, hingga busana siap pakai berfencing premium.
            </p>
        </div>

        <!-- PROMO BANNER BOX -->
        <div class="bg-[#3b2314] text-white rounded-xl p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-md">
            <div class="space-y-2">
                <span class="bg-amber-700 text-amber-100 text-[10px] uppercase font-bold px-2.5 py-1 rounded">Banner Promo Mahakarya</span>
                <h2 class="text-2xl font-serif font-bold">Diskon Spesial Hingga 25%</h2>
                <p class="text-stone-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                    Nikmati penawaran eksklusif untuk koleksi Formal Keluarga, Kemeja Sutra, dan Wastra Tradisional Lembaran. Gunakan kode kupon istimewa di keranjang belanja Anda: <span class="bg-amber-600/50 px-2 py-0.5 rounded font-mono text-amber-200 font-bold">JOYODIPO25</span>
                </p>
            </div>
            <button class="bg-amber-100 text-[#3b2314] hover:bg-white font-semibold px-5 py-2.5 rounded-lg text-xs tracking-wider transition whitespace-nowrap shadow">
                KLAIM VOUCHER & BELANJA &rarr;
            </button>
        </div>

        <!-- FILTER PILLS -->
        <div class="flex flex-wrap items-center gap-2 pt-2">
            <button class="bg-[#5c3a21] text-white text-xs px-4 py-2 rounded-full font-medium shadow-sm">Semua Koleksi (54)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full hover:bg-stone-50 font-medium">Pakaian Pria (18)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full hover:bg-stone-50 font-medium">Pakaian Wanita (16)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full hover:bg-stone-50 font-medium">Batik Tulis (14)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full hover:bg-stone-50 font-medium">Batik Cap (22)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full hover:bg-stone-50 font-medium">Sarimbit (8)</button>
        </div>

        <!-- PRODUCTS GRID -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <!-- Card 1 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow transition relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded font-medium">Pakaian Pria</span>
                <button class="absolute top-3 right-3 z-10 bg-white/80 p-1.5 rounded-full text-stone-500 hover:text-red-500 transition">❤️</button>
                <div class="h-64 bg-stone-200"></div>
                <div class="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                        <span class="text-[10px] uppercase text-stone-400 font-semibold tracking-wider">Kemeja Pria • Batik Tulis Solo</span>
                        <h3 class="font-bold text-stone-800 text-sm mt-0.5">Kemeja Pria Natawibawa Slimfit</h3>
                        <p class="text-stone-500 text-xs line-clamp-2 mt-1">Kemeja pria eksklusif bertextur benang matang...</p>
                    </div>
                    <div class="flex justify-between items-center pt-2 border-t border-stone-100">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 1.350.000</span>
                        <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs px-3 py-1.5 rounded">Beli Sekarang</button>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow transition relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded font-medium">Pakaian Wanita</span>
                <button class="absolute top-3 right-3 z-10 bg-white/80 p-1.5 rounded-full text-stone-500 hover:text-red-500 transition">❤️</button>
                <div class="h-64 bg-stone-200"></div>
                <div class="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                        <span class="text-[10px] uppercase text-stone-400 font-semibold tracking-wider">Pakaian Wanita • Cheongsam Modern</span>
                        <h3 class="font-bold text-stone-800 text-sm mt-0.5">Tunik Batik Pesisir Cheongsam</h3>
                        <p class="text-stone-500 text-xs line-clamp-2 mt-1">Batik tulis kombinasi arang flora setengah kerah...</p>
                    </div>
                    <div class="flex justify-between items-center pt-2 border-t border-stone-100">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 1.280.000</span>
                        <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs px-3 py-1.5 rounded">Beli Sekarang</button>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow transition relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded font-medium">Anak</span>
                <button class="absolute top-3 right-3 z-10 bg-white/80 p-1.5 rounded-full text-stone-500 hover:text-red-500 transition">❤️</button>
                <div class="h-64 bg-stone-200"></div>
                <div class="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                        <span class="text-[10px] uppercase text-stone-400 font-semibold tracking-wider">Pakaian Anak • Dress Katun</span>
                        <h3 class="font-bold text-stone-800 text-sm mt-0.5">Dress Anak Bunga Sekar Navy</h3>
                        <p class="text-stone-500 text-xs line-clamp-2 mt-1">Katun prima lembut nyaman untuk anak usia 3-7 tahun.</p>
                    </div>
                    <div class="flex justify-between items-center pt-2 border-t border-stone-100">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 450.000</span>
                        <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs px-3 py-1.5 rounded">Beli Sekarang</button>
                    </div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow transition relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded font-medium">Wastra</span>
                <button class="absolute top-3 right-3 z-10 bg-white/80 p-1.5 rounded-full text-stone-500 hover:text-red-500 transition">❤️</button>
                <div class="h-64 bg-stone-200"></div>
                <div class="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                        <span class="text-[10px] uppercase text-stone-400 font-semibold tracking-wider">Cirebon • Mega Mendung</span>
                        <h3 class="font-bold text-stone-800 text-sm mt-0.5">Megamendung Indigo Silk</h3>
                        <p class="text-stone-500 text-xs line-clamp-2 mt-1">Sutra asli dengan pewarnaan indigo alami bergradasi.</p>
                    </div>
                    <div class="flex justify-between items-center pt-2 border-t border-stone-100">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 1.480.000</span>
                        <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs px-3 py-1.5 rounded">Beli Sekarang</button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="bg-[#28170c] text-stone-300 pt-16 pb-8 border-t border-stone-800 mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-stone-500">
            &copy; 2026 BATIK JOYODIPO. SELURUH HAK CIPTA DILINDUNGI.
        </div>
    </footer>
</body>
</html>