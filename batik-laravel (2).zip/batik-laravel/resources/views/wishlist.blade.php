<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahakarya yang Anda Sukai - Batik Joyodipo</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            dark: '#3b2314',
                            brown: '#5c3a21',
                            light: '#fdfbf7',
                            accent: '#d4af37',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#fcfaf5] text-stone-800 font-sans antialiased">

    <!-- TOP NAVIGATION BAR -->
    <header class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="text-xl font-bold tracking-widest text-[#3b2314]">BATIK JOYODIPO</span>
            </div>

            <!-- Sub Navigation Menu -->
            <nav class="hidden md:flex space-x-6 text-xs font-semibold text-stone-600">
                <a href="index.php" class="hover:text-[#5c3a21]">BERANDA</a>
                <a href="katalog.php" class="hover:text-[#5c3a21]">KATALOG</a>
                <a href="wishlist.php" class="text-[#5c3a21] border-b-2 border-[#5c3a21] pb-1">FAVORIT SAYA</a>
            </nav>

            <div class="flex items-center space-x-4">
                <span class="text-sm cursor-pointer">🔍</span>
                <span class="text-sm cursor-pointer">🛒</span>
                <span class="bg-[#25D366] text-white text-xs px-3 py-1.5 rounded-full font-medium flex items-center gap-1">💬 WhatsApp CS</span>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        
        <!-- HEADER WISHLIST -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
            <div>
                <span class="text-xs uppercase tracking-widest text-amber-700 font-semibold">Koleksi Pribadi</span>
                <h1 class="text-2xl font-serif font-bold text-[#3b2314] mt-1">Mahakarya yang Anda Sukai</h1>
                <p class="text-stone-500 text-xs mt-1">Daftar busana dan kain batik pilihan yang telah Anda tanda hati (favorite). Simpan untuk nanti atau pindahkan langsung ke keranjang belanja Anda.</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <span class="bg-amber-50 text-amber-900 border border-amber-200 text-xs px-3 py-2 rounded-lg font-medium">❤️ 6 Mahakarya Tersimpan</span>
                <button class="bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs px-4 py-2 rounded-lg font-medium transition">🗑️ Hapus Semua</button>
                <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs px-4 py-2 rounded-lg font-medium transition shadow">🛒 Pindahkan Semua ke Keranjang</button>
            </div>
        </div>

        <!-- FILTER TABS -->
        <div class="flex flex-wrap gap-2">
            <button class="bg-[#5c3a21] text-white text-xs px-4 py-2 rounded-full font-medium">Semua Koleksi (6)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full font-medium">Pakaian Pria (3)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full font-medium">Pakaian Wanita (2)</button>
            <button class="bg-white border border-stone-300 text-stone-700 text-xs px-4 py-2 rounded-full font-medium">Pakaian Anak (1)</button>
        </div>

        <!-- ITEMS GRID -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <!-- Item 1 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded">Klasik</span>
                <button class="absolute top-3 right-3 z-10 bg-red-50 p-1.5 rounded-full text-red-500 shadow">❤️</button>
                <div class="h-60 bg-stone-200"></div>
                <div class="p-4 space-y-3">
                    <span class="text-[10px] uppercase text-stone-400 font-semibold">Pakaian Pria • Batik Tulis Solo</span>
                    <h3 class="font-bold text-stone-800 text-sm">Kemeja Pria Parang Seling...</h3>
                    <p class="text-stone-500 text-xs">Katun primissima, full furing katun adem, motif simetris rapi.</p>
                    <div class="flex items-center space-x-2">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 1.350.000</span>
                        <span class="text-xs text-stone-400 line-through">Rp 1.550.000</span>
                    </div>
                    <div class="flex gap-2 pt-2 border-t border-stone-100">
                        <button class="flex-1 bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs py-2 rounded font-medium">🛒 Ke Keranjang</button>
                        <button class="p-2 border border-stone-300 rounded text-stone-500 hover:bg-stone-50 text-xs">🗑️</button>
                    </div>
                </div>
            </div>

            <!-- Item 2 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded">Modern</span>
                <button class="absolute top-3 right-3 z-10 bg-red-50 p-1.5 rounded-full text-red-500 shadow">❤️</button>
                <div class="h-60 bg-stone-200"></div>
                <div class="p-4 space-y-3">
                    <span class="text-[10px] uppercase text-stone-400 font-semibold">Pakaian Wanita • Cheongsam</span>
                    <h3 class="font-bold text-stone-800 text-sm">Tunik Batik Pesisir...</h3>
                    <p class="text-stone-500 text-xs">Kerah shanghai klasik, kancing shanghai handmade, sutra halus.</p>
                    <div class="flex items-center space-x-2">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 1.280.000</span>
                    </div>
                    <div class="flex gap-2 pt-2 border-t border-stone-100">
                        <button class="flex-1 bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs py-2 rounded font-medium">🛒 Ke Keranjang</button>
                        <button class="p-2 border border-stone-300 rounded text-stone-500 hover:bg-stone-50 text-xs">🗑️</button>
                    </div>
                </div>
            </div>

            <!-- Item 3 -->
            <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm relative flex flex-col justify-between">
                <span class="absolute top-3 left-3 z-10 bg-[#3b2314] text-white text-[10px] px-2.5 py-0.5 rounded">Anak</span>
                <button class="absolute top-3 right-3 z-10 bg-red-50 p-1.5 rounded-full text-red-500 shadow">❤️</button>
                <div class="h-60 bg-stone-200"></div>
                <div class="p-4 space-y-3">
                    <span class="text-[10px] uppercase text-stone-400 font-semibold">Pakaian Anak • Dress Katun</span>
                    <h3 class="font-bold text-stone-800 text-sm">Dress Anak Bunga Sekar Navy</h3>
                    <p class="text-stone-500 text-xs">Katun prima lembut, ramah untuk anak usia 2-5 tahun.</p>
                    <div class="flex items-center space-x-2">
                        <span class="font-bold text-[#5c3a21] text-sm">Rp 450.000</span>
                    </div>
                    <div class="flex gap-2 pt-2 border-t border-stone-100">
                        <button class="flex-1 bg-[#5c3a21] hover:bg-[#3b2314] text-white text-xs py-2 rounded font-medium">🛒 Ke Keranjang</button>
                        <button class="p-2 border border-stone-300 rounded text-stone-500 hover:bg-stone-50 text-xs">🗑️</button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="bg-[#28170c] text-stone-300 pt-16 pb-8 border-t border-stone-800 mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-stone-500">
            &copy; 2026 BATIK JOYODIPO. SELURUH HAK CIPTA DILINDUNGI.
        </div>
    </footer>
</body>
</html>