<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja - Batik Joyodipo</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            dark: '#3b2314',
                            brown: '#5c3a21',
                            light: '#fdfbf7',
                            accent: '#d4af37',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#fcfaf5] text-stone-800 font-sans antialiased">

    <!-- TOP NAVIGATION BAR -->
    <header class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="text-xl font-bold tracking-widest text-[#3b2314]">BATIK JOYODIPO</span>
            </div>
            <nav class="hidden md:flex space-x-6 text-xs font-semibold text-stone-600">
                <a href="index.php" class="hover:text-[#5c3a21]">BERANDA</a>
                <a href="katalog.php" class="hover:text-[#5c3a21]">KATALOG</a>
                <a href="keranjang.php" class="text-[#5c3a21] border-b-2 border-[#5c3a21] pb-1">KERANJANG</a>
            </nav>
            <div class="flex items-center space-x-4">
                <span class="text-sm cursor-pointer">🔍</span>
                <span class="bg-[#25D366] text-white text-xs px-3 py-1.5 rounded-full font-medium flex items-center gap-1">💬 WhatsApp CS</span>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <!-- HEADER KERANJANG -->
        <div class="border-b border-stone-200 pb-4">
            <div class="flex items-center space-x-2 text-xs text-stone-500 mb-1 font-medium">
                <span class="text-amber-700 font-bold">1. Keranjang</span> &rarr; <span class="text-stone-400">2. Pengiriman</span> &rarr; <span class="text-stone-400">3. Pembayaran</span>
            </div>
            <h1 class="text-3xl font-serif font-bold text-[#3b2314]">Keranjang Belanja Mahakarya</h1>
            <p class="text-stone-600 text-xs mt-1">Periksa dan sesuaikan daftar busana batik pilihan Anda sebelum melanjutkan ke kalkulasi pengiriman.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Kiri: Daftar Item Keranjang -->
            <div class="lg:col-span-2 space-y-4">
                <!-- Bar Item 1 -->
                <div class="bg-white p-4 rounded-xl border border-stone-200 flex items-center justify-between gap-4 shadow-sm">
                    <input type="checkbox" checked class="accent-[#5c3a21] w-4 h-4">
                    <div class="w-20 h-20 bg-stone-200 rounded-lg flex-shrink-0"></div>
                    <div class="flex-1 space-y-1">
                        <span class="text-[10px] uppercase text-stone-400 font-bold">Pakaian Pria • Batik Tulis Solo</span>
                        <h3 class="font-bold text-stone-800 text-sm">Kemeja Pria Parang Seling Indigo</h3>
                        <p class="text-xs text-stone-500">Ukuran: L • Furing Katun • Asal Sragen</p>
                        <span class="font-bold text-[#5c3a21] text-sm block">Rp 1.350.000</span>
                    </div>
                    <div class="flex flex-col items-end justify-between h-20">
                        <button class="text-stone-400 hover:text-red-500 text-xs">🗑️</button>
                        <div class="flex items-center border border-stone-300 rounded text-xs">
                            <button class="px-2 py-0.5 bg-stone-100">-</button>
                            <span class="px-3">1</span>
                            <button class="px-2.5 py-0.5 bg-stone-100">+</button>
                        </div>
                    </div>
                </div>

                <!-- Bar Item 2 -->
                <div class="bg-white p-4 rounded-xl border border-stone-200 flex items-center justify-between gap-4 shadow-sm">
                    <input type="checkbox" checked class="accent-[#5c3a21] w-4 h-4">
                    <div class="w-20 h-20 bg-stone-200 rounded-lg flex-shrink-0"></div>
                    <div class="flex-1 space-y-1">
                        <span class="text-[10px] uppercase text-stone-400 font-bold">Pakaian Wanita • Cheongsam Modern</span>
                        <h3 class="font-bold text-stone-800 text-sm">Tunik Batik Pesisir Cheongsam</h3>
                        <p class="text-xs text-stone-500">Ukuran: M • Kerang Shanghai • Sutra Halus</p>
                        <span class="font-bold text-[#5c3a21] text-sm block">Rp 1.280.000</span>
                    </div>
                    <div class="flex flex-col items-end justify-between h-20">
                        <button class="text-stone-400 hover:text-red-500 text-xs">🗑️</button>
                        <div class="flex items-center border border-stone-300 rounded text-xs">
                            <button class="px-2 py-0.5 bg-stone-100">-</button>
                            <span class="px-3">1</span>
                            <button class="px-2.5 py-0.5 bg-stone-100">+</button>
                        </div>
                    </div>
                </div>

                <!-- Kotak Kupon Diskon -->
                <div class="bg-white p-6 rounded-xl border border-stone-200 space-y-3">
                    <h3 class="text-xs font-bold text-stone-700">Kupon & Voucher Hak Istimewa</h3>
                    <div class="flex gap-2">
                        <input type="text" placeholder="Masukkan kode kupon, misal: JOYODIPO25" class="flex-1 bg-stone-50 border border-stone-300 rounded-lg px-4 py-2 text-xs focus:outline-none">
                        <button class="bg-[#5c3a21] text-white text-xs px-5 py-2 rounded-lg font-semibold">Gunakan</button>
                    </div>
                </div>
            </div>

            <!-- Kanan: Ringkasan Pesanan (Checkout Summary) -->
            <div class="bg-white p-6 rounded-xl border border-stone-200 shadow-sm space-y-6 h-fit">
                <h3 class="font-serif font-bold text-lg text-[#3b2314] border-b border-stone-100 pb-3">Ringkasan Pesanan</h3>
                <div class="space-y-3 text-xs">
                    <div class="flex justify-between text-stone-600">
                        <span>Subtotal (2 Item)</span>
                        <span class="font-semibold">Rp 2.630.000</span>
                    </div>
                    <div class="flex justify-between text-stone-600">
                        <span>Diskon Kupon</span>
                        <span class="text-emerald-700 font-semibold">- Rp 263.000</span>
                    </div>
                    <div class="flex justify-between text-stone-600">
                        <span>Estimasi Ongkir</span>
                        <span class="text-stone-400 italic">Dihitung saat checkout</span>
                    </div>
                    <div class="border-t border-stone-200 pt-3 flex justify-between items-center">
                        <span class="font-bold text-stone-800 text-sm">Total Tagihan</span>
                        <span class="font-bold text-lg text-[#5c3a21]">Rp 2.367.000</span>
                    </div>
                </div>
                <button class="w-full bg-[#5c3a21] hover:bg-[#3b2314] text-white font-semibold py-3 rounded-xl text-xs transition shadow text-center block">
                    LANJUT KE PENGIRIMAN &rarr;
                </button>
                <p class="text-[10px] text-stone-400 text-center">🔒 Terlindung Midtrans & Garansi Kurasi 100%</p>
            </div>
        </div>
    </main>

    <footer class="bg-[#28170c] text-stone-300 pt-16 pb-8 border-t border-stone-800 mt-20 text-center text-xs text-stone-500">
        &copy; 2026 BATIK JOYODIPO. SELURUH HAK CIPTA DILINDUNGI.
    </footer>
</body>
</html>