<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Batik Joyodipo - Artistry in Every Thread</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            dark: '#3b2314',
                            brown: '#5c3a21',
                            light: '#fdfbf7',
                            accent: '#d4af37',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#fcfaf5] text-stone-800 font-sans antialiased">

    <!-- TOP NAVIGATION BAR -->
    <header class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <!-- Logo -->
            <div class="flex items-center space-x-2">
                <span class="text-xl font-bold tracking-widest text-[#3b2314]">BATIK JOYODIPO</span>
            </div>

            <!-- Search Bar -->
            <div class="hidden md:flex items-center flex-1 max-w-md mx-8">
                <div class="relative w-full">
                    <input type="text" placeholder="Cari koleksi batik, motif, atau busana..." class="w-full bg-stone-100 border border-stone-300 rounded-full py-2 pl-4 pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-[#5c3a21]">
                    <span class="absolute right-3 top-2.5 text-stone-400">🔍</span>
                </div>
            </div>

            <!-- Nav Links & Actions -->
            <div class="flex items-center space-x-6 text-sm font-medium">
                <nav class="hidden lg:flex space-x-6 text-stone-700">
                    <a href="#" class="hover:text-[#5c3a21]">Beranda</a>
                    <a href="#" class="hover:text-[#5c3a21]">Atelier</a>
                    <a href="#" class="hover:text-[#5c3a21]">Koleksi</a>
                    <a href="#" class="hover:text-[#5c3a21]">Sarimbit</a>
                </nav>
                <div class="flex items-center space-x-4 border-l pl-6 border-stone-300">
                    <a href="#" class="text-stone-700 hover:text-[#5c3a21]">🛒</a>
                    <a href="#" class="bg-[#5c3a21] text-white px-4 py-2 rounded-full text-xs font-semibold hover:bg-[#3b2314] transition">Akun Saya</a>
                </div>
            </div>
        </div>
    </header>

    <!-- HERO SECTION -->
    <section class="relative bg-[#3b2314] text-white py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div class="absolute inset-0 opacity-30 bg-cover bg-center" style="background-image: url('https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1600');"></div>
        <div class="relative max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div class="space-y-6">
                <span class="text-xs uppercase tracking-widest bg-[#5c3a21] px-3 py-1 rounded text-amber-200">Koleksi Eksklusif Wastra Nusantara</span>
                <h1 class="text-4xl sm:text-5xl font-serif font-bold leading-tight">Artistry in Every Thread</h1>
                <p class="text-stone-300 text-sm sm:text-base leading-relaxed">
                    Setiap helaian benang merajut cerita warisan budaya, menghadirkan mahakarya batik tulis dan cap dengan sentuhan modern yang elegan untuk Anda.
                </p>
                <div class="flex space-x-4 pt-2">
                    <a href="#" class="bg-amber-600 hover:bg-amber-700 text-white font-medium px-6 py-3 rounded-md text-sm transition">Koleksi Wastra Pilihan</a>
                    <a href="#" class="border border-stone-400 hover:border-white text-white font-medium px-6 py-3 rounded-md text-sm transition">Jelajahi Atelier Kami</a>
                </div>
            </div>
        </div>
    </section>

    <!-- E-COMMERCE PARTNERS BADGE -->
    <div class="bg-stone-100 py-6 border-b border-stone-200">
        <div class="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-center gap-8 text-stone-500 text-sm font-semibold">
            <span>OUR E-COMMERCE PARTNERS:</span>
            <div class="flex items-center space-x-6">
                <span class="bg-white px-4 py-2 rounded shadow-sm border border-stone-200">MIDTRANS</span>
                <span class="bg-white px-4 py-2 rounded shadow-sm border border-stone-200">RajaOngkir</span>
                <span class="bg-white px-4 py-2 rounded shadow-sm border border-stone-200">JNE / J&T</span>
                <span class="bg-white px-4 py-2 rounded shadow-sm border border-stone-200">WhatsApp API</span>
            </div>
        </div>
    </div>

    <!-- KOLEKSI BUSANA & WASTRA PILIHAN -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
        
        <section>
            <div class="flex justify-between items-end mb-8">
                <div>
                    <h2 class="text-2xl font-serif font-bold text-[#3b2314]">Koleksi Busana & Wastra Pilihan</h2>
                    <p class="text-stone-500 text-sm mt-1">Mahakarya pilihan dengan kualitas material terbaik.</p>
                </div>
                <a href="#" class="text-sm font-semibold text-[#5c3a21] hover:underline">Lihat Semua &rarr;</a>
            </div>

            <!-- Product Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                <!-- Card 1 -->
                <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition">
                    <div class="h-56 bg-stone-200 relative">
                        <span class="absolute top-2 left-2 bg-[#3b2314] text-white text-[10px] px-2 py-0.5 rounded">Batik Tulis</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <h3 class="font-medium text-stone-800 text-sm">Kemeja Pria Mega Mendung</h3>
                        <p class="text-stone-500 text-xs line-clamp-2">Katun prima halus dengan corak klasik kontemporer.</p>
                        <div class="flex justify-between items-center pt-2">
                            <span class="font-bold text-[#5c3a21] text-sm">Rp 450.000</span>
                            <button class="bg-[#5c3a21] text-white text-xs px-3 py-1.5 rounded hover:bg-[#3b2314]">Beli</button>
                        </div>
                    </div>
                </div>
                <!-- Card 2 -->
                <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition">
                    <div class="h-56 bg-stone-200 relative">
                        <span class="absolute top-2 left-2 bg-[#3b2314] text-white text-[10px] px-2 py-0.5 rounded">Batik Cap</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <h3 class="font-medium text-stone-800 text-sm">Dress Wanita Parang Kencana</h3>
                        <p class="text-stone-500 text-xs line-clamp-2">Elegan untuk acara formal maupun semi-formal.</p>
                        <div class="flex justify-between items-center pt-2">
                            <span class="font-bold text-[#5c3a21] text-sm">Rp 650.000</span>
                            <button class="bg-[#5c3a21] text-white text-xs px-3 py-1.5 rounded hover:bg-[#3b2314]">Beli</button>
                        </div>
                    </div>
                </div>
                <!-- Card 3 -->
                <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition">
                    <div class="h-56 bg-stone-200 relative">
                        <span class="absolute top-2 left-2 bg-[#3b2314] text-white text-[10px] px-2 py-0.5 rounded">Anak</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <h3 class="font-medium text-stone-800 text-sm">Setelan Anak Katun Batik</h3>
                        <p class="text-stone-500 text-xs line-clamp-2">Nyaman dan lembut untuk buah hati tercinta.</p>
                        <div class="flex justify-between items-center pt-2">
                            <span class="font-bold text-[#5c3a21] text-sm">Rp 250.000</span>
                            <button class="bg-[#5c3a21] text-white text-xs px-3 py-1.5 rounded hover:bg-[#3b2314]">Beli</button>
                        </div>
                    </div>
                </div>
                <!-- Card 4 -->
                <div class="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition">
                    <div class="h-56 bg-stone-200 relative">
                        <span class="absolute top-2 left-2 bg-[#3b2314] text-white text-[10px] px-2 py-0.5 rounded">Wastra</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <h3 class="font-medium text-stone-800 text-sm">Kain Kain Tulis Eksklusif</h3>
                        <p class="text-stone-500 text-xs line-clamp-2">Lembaran kain siap jahit untuk berbagai kreasi busana.</p>
                        <div class="flex justify-between items-center pt-2">
                            <span class="font-bold text-[#5c3a21] text-sm">Rp 1.250.000</span>
                            <button class="bg-[#5c3a21] text-white text-xs px-3 py-1.5 rounded hover:bg-[#3b2314]">Beli</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- PROMO BANNER -->
        <section class="bg-[#3b2314] text-white rounded-2xl p-8 sm:p-12 relative overflow-hidden flex flex-col sm:flex-row justify-between items-center">
            <div class="space-y-3 z-10">
                <span class="bg-amber-600 text-xs uppercase px-3 py-1 rounded font-semibold">Penawaran Terbatas</span>
                <h3 class="text-2xl sm:text-3xl font-serif font-bold">Diskon Spesial Hingga 25%</h3>
                <p class="text-stone-300 text-sm max-w-xl">Nikmati potongan harga khusus untuk koleksi Sarimbit pilihan selama bulan perayaan budaya Nusantara.</p>
            </div>
            <div class="mt-6 sm:mt-0 z-10">
                <a href="#" class="bg-white text-[#3b2314] hover:bg-stone-100 font-semibold px-6 py-3 rounded-lg text-sm shadow transition">Klaim Kupon Promo</a>
            </div>
        </section>

    </main>

    <!-- FOOTER -->
    <footer class="bg-[#28170c] text-stone-300 pt-16 pb-8 border-t border-stone-800 mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10">
            <div class="space-y-4">
                <h4 class="text-white font-bold tracking-widest text-lg">BATIK JOYODIPO</h4>
                <p class="text-xs text-stone-400 leading-relaxed">
                    Platform e-commerce resmi wastra dan atelier Batik Joyodipo. Menjaga keaslian motif dan kualitas tinggi warisan leluhur.
                </p>
            </div>
            <div>
                <h5 class="text-white text-sm font-semibold mb-4">Kategori Utama</h5>
                <ul class="space-y-2 text-xs">
                    <li><a href="#" class="hover:text-white">Batik Tulis Klasik</a></li>
                    <li><a href="#" class="hover:text-white">Batik Cap Modern</a></li>
                    <li><a href="#" class="hover:text-white">Koleksi Sarimbit</a></li>
                    <li><a href="#" class="hover:text-white">Wastra Nusantara</a></li>
                </ul>
            </div>
            <div>
                <h5 class="text-white text-sm font-semibold mb-4">Layanan Pelanggan</h5>
                <ul class="space-y-2 text-xs">
                    <li><a href="#" class="hover:text-white">Panduan Ukuran & Fitting</a></li>
                    <li><a href="#" class="hover:text-white">Cek Status Pesanan</a></li>
                    <li><a href="#" class="hover:text-white">Konsultasi via WhatsApp</a></li>
                </ul>
            </div>
            <div>
                <h5 class="text-white text-sm font-semibold mb-4">Lokasi Atelier</h5>
                <p class="text-xs text-stone-400 leading-relaxed">
                    Jl. Batik Joyodipo No. 45, Surakarta, Jawa Tengah, Indonesia.
                </p>
            </div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-12 border-t border-stone-800 text-center text-xs text-stone-500">
            &copy; 2026 Batik Joyodipo. All Rights Reserved.
        </div>
    </footer>

</body>
</html>