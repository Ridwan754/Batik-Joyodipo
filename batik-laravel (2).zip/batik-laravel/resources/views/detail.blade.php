<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Batik Joyodipo</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            dark: '#3b2314',
                            brown: '#5c3a21',
                            light: '#fdfbf7',
                            accent: '#d4af37',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#fcfaf5] text-stone-800 font-sans antialiased">

    <!-- TOP NAVIGATION BAR -->
    <header class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="text-xl font-bold tracking-widest text-[#3b2314]">BATIK JOYODIPO</span>
            </div>
            <nav class="hidden md:flex space-x-6 text-xs font-semibold text-stone-600">
                <a href="index.php" class="hover:text-[#5c3a21]">BERANDA</a>
                <a href="katalog.php" class="text-[#5c3a21] border-b-2 border-[#5c3a21] pb-1">KATALOG</a>
                <a href="wishlist.php" class="hover:text-[#5c3a21]">FAVORIT SAYA</a>
            </nav>
            <div class="flex items-center space-x-4">
                <span class="text-sm cursor-pointer">🔍</span>
                <span class="text-sm cursor-pointer">🛒</span>
                <span class="bg-[#25D366] text-white text-xs px-3 py-1.5 rounded-full font-medium flex items-center gap-1">💬 WhatsApp CS</span>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
        <p class="text-xs text-stone-500 uppercase tracking-widest">Beranda > Katalog > Pakaian Pria > Kemeja Pria Parang Kading Indigo</p>

        <!-- DETAIL UTAMA PRODUK -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
            <!-- Kolom Gambar -->
            <div class="space-y-4">
                <div class="h-[450px] bg-stone-200 rounded-xl flex items-center justify-center text-stone-400 font-medium">
                    [Foto Utama Produk - Tampak Belakang]
                </div>
                <div class="grid grid-cols-4 gap-3">
                    <div class="h-24 bg-stone-100 rounded-lg border-2 border-[#5c3a21]"></div>
                    <div class="h-24 bg-stone-100 rounded-lg"></div>
                    <div class="h-24 bg-stone-100 rounded-lg"></div>
                    <div class="h-24 bg-stone-100 rounded-lg"></div>
                </div>
            </div>

            <!-- Kolom Informasi & Aksi -->
            <div class="space-y-6">
                <div>
                    <span class="text-xs uppercase bg-[#3b2314] text-white px-2.5 py-1 rounded font-semibold">Official Mahakarya</span>
                    <h1 class="text-2xl sm:text-3xl font-serif font-bold text-[#3b2314] mt-3">Kemeja Pria Motif Kamandanu Kekinian Lapis Furing</h1>
                </div>

                <div class="flex items-baseline space-x-3">
                    <span class="text-3xl font-bold text-[#5c3a21]">Rp 1.350.000</span>
                    <span class="text-sm text-stone-400 line-through">Rp 1.550.000</span>
                    <span class="text-xs bg-red-100 text-red-800 font-semibold px-2 py-0.5 rounded">Hemat 13%</span>
                </div>

                <div class="text-xs text-stone-600 space-y-1 border-y border-stone-200 py-4">
                    <p><strong>Pengiriman:</strong> Bebas Ongkir Seluruh Indonesia (Syarat & Ketentuan Berlaku)</p>
                    <p><strong>Garansi:</strong> Garansi Tukar Ukuran 7 Hari</p>
                </div>

                <!-- Pilihan Ukuran -->
                <div class="space-y-3">
                    <div class="flex justify-between text-xs">
                        <span class="font-bold text-stone-700">Pilih Ukuran</span>
                        <a href="#tabel-ukuran" class="text-[#5c3a21] underline"> Panduan Ukuran (Size Chart)</a>
                    </div>
                    <div class="flex space-x-2">
                        <button class="w-12 h-10 border border-stone-300 rounded text-xs font-semibold hover:border-[#5c3a21]">S</button>
                        <button class="w-12 h-10 border border-stone-300 rounded text-xs font-semibold hover:border-[#5c3a21]">M</button>
                        <button class="w-12 h-10 bg-[#5c3a21] text-white rounded text-xs font-semibold">L</button>
                        <button class="w-12 h-10 border border-stone-300 rounded text-xs font-semibold hover:border-[#5c3a21]">XL</button>
                        <button class="w-12 h-10 border border-stone-300 rounded text-xs font-semibold hover:border-[#5c3a21]">XXL</button>
                    </div>
                </div>

                <!-- Tabel Ukuran Mini -->
                <div id="tabel-ukuran" class="bg-stone-50 p-4 rounded-xl border border-stone-200 text-xs">
                    <p class="font-bold text-stone-700 mb-2">Tabel Lingkar Dada & Panjang:</p>
                    <table class="w-full text-left">
                        <thead>
                            <tr class="border-b text-stone-500">
                                <th class="py-1">Size</th>
                                <th class="py-1">Lingkar Dada</th>
                                <th class="py-1">Panjang</th>
                                <th class="py-1">Lengan</th>
                            </tr>
                        </thead>
                        <tbody class="text-stone-700">
                            <tr><td>L</td><td>112 cm</td><td>75 cm</td><td>62 cm</td></tr>
                            <tr><td>XL</td><td>116 cm</td><td>77 cm</td><td>63 cm</td></tr>
                        </tbody>
                    </table>
                </div>

                <!-- Kuantitas & Tombol Beli -->
                <div class="space-y-4 pt-2">
                    <div class="flex items-center space-x-4">
                        <span class="text-xs font-bold text-stone-700">Kuantitas:</span>
                        <div class="flex items-center border border-stone-300 rounded">
                            <button class="px-3 py-1 bg-stone-100">-</button>
                            <span class="px-4 text-xs font-bold">1</span>
                            <button class="px-3 py-1 bg-stone-100">+</button>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <button class="border border-[#5c3a21] text-[#5c3a21] hover:bg-amber-50 font-semibold py-3 rounded-xl text-xs transition">🛒 + Keranjang</button>
                        <button class="bg-[#5c3a21] hover:bg-[#3b2314] text-white font-semibold py-3 rounded-xl text-xs transition shadow">Beli Sekarang</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- DESKRIPSI PRODUK -->
        <div class="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm space-y-4">
            <h3 class="text-lg font-serif font-bold text-[#3b2314]">Deskripsi Produk</h3>
            <p class="text-xs text-stone-600 leading-relaxed">
                Kemeja Katun Pria Parang Kading Indigo Koleksi Klasik dirancang khusus untuk pria yang mengutamakan kerapian berbusana formal, kerja, maupun acara perjamuan resmi kenegaraan dan pesta resepsi. 
            </p>
            <ul class="list-disc list-inside text-xs text-stone-600 space-y-1">
                <li>Bahan katun prima pilihan dibuat menggunakan kain katun primissima super halus, lembut diserap keringat dengan tingkat keawetan tinggi.</li>
                <li>Pola Motif Menyambung (Pattern Matched) pada bagian kancing depan dan kantong saku dipotong secara teliti.</li>
                <li>Lapisan Furing Katun Adem di bagian dalam menjamin kenyamanan maksimal saat dikenakan seharian.</li>
            </ul>
        </div>
    </main>

    <footer class="bg-[#28170c] text-stone-300 pt-16 pb-8 border-t border-stone-800 mt-20 text-center text-xs text-stone-500">
        &copy; 2026 BATIK JOYODIPO. SELURUH HAK CIPTA DILINDUNGI.
    </footer>
</body>
</html>