<?php

use App\Http\Controllers\Api\AddressController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\HomeController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\PaymentWebhookController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ProductVariantController;
use App\Http\Controllers\Api\RajaOngkirController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\VoucherController;
use App\Http\Controllers\Api\WishlistController;
use Illuminate\Support\Facades\Route;

// =======================
// 1. PUBLIC ROUTES
// =======================
// Rate limit: mencegah brute force (login) dan spam akun (register)
Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:register');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:login');

// Beranda (ringkasan kategori & produk unggulan/terbaru)
Route::get('/home', [HomeController::class, 'index']);

// Katalog Produk & Kategori
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/categories/{id}', [CategoryController::class, 'show']);

Route::get('/products', [ProductController::class, 'index']);
// Pencarian produk: harus sebelum /products/{slug} agar tidak tertangkap wildcard
Route::get('/products/search', [ProductController::class, 'search']);
Route::get('/products/{slug}', [ProductController::class, 'show']);

// Ulasan produk (publik)
Route::get('/products/{slug}/reviews', [ReviewController::class, 'index']);

// Webhook Pembayaran Midtrans
Route::post('/payments/webhook', [PaymentWebhookController::class, 'handle']);

// =======================
// 2. PROTECTED ROUTES (LOGGED IN USER)
// =======================
Route::middleware('auth:sanctum')->group(function () {

    // Autentikasi
    Route::get('/me', [AuthController::class, 'me']);
    Route::put('/profile', [AuthController::class, 'updateProfile']);
    Route::post('/logout', [AuthController::class, 'logout']);

    // Wishlist
    Route::get('/wishlist', [WishlistController::class, 'index']);
    Route::post('/wishlist', [WishlistController::class, 'store']);
    Route::delete('/wishlist/{id}', [WishlistController::class, 'destroy']);

    // Keranjang (Cart)
    Route::get('/cart', [CartController::class, 'index']);
    Route::post('/cart/items', [CartController::class, 'addItem']);
    Route::put('/cart/items/{id}', [CartController::class, 'updateItem']);
    Route::delete('/cart/items/{id}', [CartController::class, 'removeItem']);
    Route::delete('/cart', [CartController::class, 'clearCart']);

    // Manajemen Alamat
    Route::get('/addresses', [AddressController::class, 'index']);
    Route::post('/addresses', [AddressController::class, 'store']);
    Route::get('/addresses/{id}', [AddressController::class, 'show']);
    Route::put('/addresses/{id}', [AddressController::class, 'update']);
    Route::put('/addresses/{id}/set-primary', [AddressController::class, 'setPrimary']);
    Route::delete('/addresses/{id}', [AddressController::class, 'destroy']);

    // Transaksi Customer
    Route::get('/orders/me', [OrderController::class, 'myOrders']);
    Route::post('/orders', [OrderController::class, 'store']);
    // Checkout langsung dari isi keranjang
    Route::post('/orders/from-cart', [OrderController::class, 'storeFromCart']);
    Route::get('/orders/{id}', [OrderController::class, 'show']);
    Route::get('/orders/{id}/shipment', [OrderController::class, 'shipment']);
    Route::post('/orders/{id}/cancel', [OrderController::class, 'cancel']);

    // Ulasan Produk (Review)
    Route::post('/orders/{id}/reviews', [ReviewController::class, 'store']);
    Route::delete('/reviews/{id}', [ReviewController::class, 'destroy']);

    // Cek Ongkos Kirim (RajaOngkir)
    Route::post('/shipping/cost', [RajaOngkirController::class, 'checkCost']);

    // Customer Voucher Routes
    Route::get('/vouchers/available', [VoucherController::class, 'available']);
    Route::post('/vouchers/validate', [VoucherController::class, 'validateVoucher']);
    Route::get('/voucher-usages/me', [VoucherController::class, 'myUsages']);

    // =======================
    // 3. ADMIN ONLY ROUTES
    // =======================
    Route::middleware('role:admin')->group(function () {
        // Dashboard statistik admin
        Route::get('/dashboard', [DashboardController::class, 'index']);

        // Voucher (Admin)
        Route::get('/vouchers', [VoucherController::class, 'index']);
        Route::post('/vouchers', [VoucherController::class, 'store']);
        Route::get('/vouchers/{id}', [VoucherController::class, 'show']);
        Route::put('/vouchers/{id}', [VoucherController::class, 'update']);
        Route::delete('/vouchers/{id}', [VoucherController::class, 'destroy']);

        // Order (Admin)
        Route::get('/orders', [OrderController::class, 'index']);
        Route::patch('/orders/{id}/status', [OrderController::class, 'updateStatus']);
        // Input resi/pengiriman: otomatis menandai pesanan sebagai shipped
        Route::post('/orders/{id}/shipment', [OrderController::class, 'storeShipment']);
        Route::put('/orders/{id}/shipment', [OrderController::class, 'storeShipment']);

        // Kategori (Admin)
        Route::post('/categories', [CategoryController::class, 'store']);
        Route::put('/categories/{id}', [CategoryController::class, 'update']);
        Route::delete('/categories/{id}', [CategoryController::class, 'destroy']);

        // Produk (Admin) — index pengelolaan pakai prefix /admin
        // agar tidak bentrok dengan wildcard publik /products/{slug}
        Route::get('/admin/products', [ProductController::class, 'adminIndex']);
        Route::post('/products', [ProductController::class, 'store']);
        Route::put('/products/{id}', [ProductController::class, 'update']);
        Route::delete('/products/{id}', [ProductController::class, 'destroy']);

        // Varian Produk (Admin)
        Route::get('/variants', [ProductVariantController::class, 'index']);
        Route::post('/variants', [ProductVariantController::class, 'store']);
        Route::post('/products/{id}/variants', [ProductVariantController::class, 'store']);
        Route::put('/variants/{id}', [ProductVariantController::class, 'update']);
        Route::delete('/variants/{id}', [ProductVariantController::class, 'destroy']);
    });
});
