<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use Illuminate\Http\Request;

class ProductVariantController extends Controller
{
    // GET /api/variants?product_id= (Admin)
    // Mengambil daftar varian, opsional difilter berdasarkan produk tertentu
    public function index(Request $request)
    {
        $request->validate([
            'product_id' => 'nullable|integer|exists:products,id',
        ]);

        $query = ProductVariant::with('product:id,name,slug');

        if ($request->filled('product_id')) {
            $query->where('product_id', $request->product_id);
        }

        return response()->json([
            'status' => 'success',
            'data' => $query->latest()->get(),
        ]);
    }

    // POST /api/variants (Admin)
    // atau POST /api/products/{id}/variants (Admin): product_id dapat diambil dari path
    public function store(Request $request)
    {
        // Pada rute product-scoped, ID produk dari path menjadi otoritatif
        $routeProductId = $request->route('id');
        if ($routeProductId !== null) {
            $request->merge(['product_id' => $routeProductId]);
        }

        $data = $request->validate([
            'product_id' => 'required|integer|exists:products,id',
            'sku' => 'required|string|max:100|unique:product_variants,sku',
            'size' => 'required|in:S,M,L,XL,XXL,Custom',
            'chest_size_cm' => 'nullable|integer|min:0',
            'body_length_cm' => 'nullable|integer|min:0',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'weight_g' => 'nullable|integer|min:0',
        ]);

        $variant = ProductVariant::create($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Varian produk berhasil dibuat.',
            'data' => $variant,
        ], 201);
    }

    // PUT /api/variants/{id} (Admin)
    public function update(Request $request, $id)
    {
        $variant = ProductVariant::findOrFail($id);

        $data = $request->validate([
            'product_id' => 'sometimes|required|integer|exists:products,id',
            'sku' => 'sometimes|required|string|max:100|unique:product_variants,sku,'.$id,
            'size' => 'sometimes|required|in:S,M,L,XL,XXL,Custom',
            'chest_size_cm' => 'nullable|integer|min:0',
            'body_length_cm' => 'nullable|integer|min:0',
            'price' => 'sometimes|required|numeric|min:0',
            'stock' => 'sometimes|required|integer|min:0',
            'weight_g' => 'nullable|integer|min:0',
        ]);

        $variant->update($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Varian produk berhasil diperbarui.',
            'data' => $variant->fresh('product:id,name,slug'),
        ]);
    }

    // DELETE /api/variants/{id} (Admin)
    public function destroy($id)
    {
        $variant = ProductVariant::findOrFail($id);

        // order_items.product_variant_id memakai ON DELETE CASCADE,
        // sehingga varian yang pernah dipesan tidak boleh dihapus
        // agar riwayat pesanan tetap utuh.
        $isUsed = OrderItem::where('product_variant_id', $variant->id)->exists();

        if ($isUsed) {
            return response()->json([
                'status' => 'error',
                'message' => 'Varian tidak dapat dihapus karena sudah menjadi bagian dari riwayat pesanan. Nonaktifkan dengan mengubah stok ke 0 atau gunakan produk lain.',
            ], 400);
        }

        $variant->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Varian produk berhasil dihapus.',
        ]);
    }
}
