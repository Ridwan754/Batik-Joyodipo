<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserAddress;
use Illuminate\Http\Request;

class AddressController extends Controller
{
    // GET /api/addresses
    public function index(Request $request)
    {
        $addresses = UserAddress::where('user_id', $request->user()->id)
            ->orderBy('is_primary', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $addresses,
        ]);
    }

    // POST /api/addresses
    public function store(Request $request)
    {
        $request->validate([
            'label_alamat' => 'required|string|max:30',
            'nama_penerima' => 'required|string|max:100',
            'nomor_telepon' => 'required|string|max:20',
            'nama_provinsi' => 'required|string|max:60',
            'nama_kota' => 'required|string|max:60',
            'nama_kecamatan' => 'required|string|max:60',
            'kota_id' => 'nullable|integer',
            'kode_pos' => 'required|string|max:10',
            'alamat_lengkap' => 'required|string',
            'alamat_utama' => 'boolean',
        ]);

        $isPrimary = $request->alamat_utama ?? false;

        $hasAddress = UserAddress::where('user_id', $request->user()->id)->exists();
        if (! $hasAddress) {
            $isPrimary = true;
        }

        if ($isPrimary) {
            UserAddress::where('user_id', $request->user()->id)->update(['is_primary' => false]);
        }

        $address = UserAddress::create([
            'user_id' => $request->user()->id,
            'label' => $request->label_alamat,
            'recipient_name' => $request->nama_penerima,
            'phone' => $request->nomor_telepon,
            'address_line' => $request->alamat_lengkap,
            'city_id' => $request->kota_id ?? null,
            'city_name' => $request->nama_kota,
            'province_name' => $request->nama_provinsi,
            'district_name' => $request->nama_kecamatan,
            'postal_code' => $request->kode_pos,
            'is_primary' => $isPrimary,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Alamat berhasil ditambahkan.',
            'data' => $address,
        ], 201);
    }

    // GET /api/addresses/{id}
    public function show(Request $request, $id)
    {
        $address = UserAddress::where('id', $id)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $address) {
            return response()->json([
                'success' => false,
                'message' => 'Data alamat tidak ditemukan.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $address,
        ]);
    }

    // PUT /api/addresses/{id}
    public function update(Request $request, $id)
    {
        $address = UserAddress::where('id', $id)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $address) {
            return response()->json([
                'success' => false,
                'message' => 'Data alamat tidak ditemukan.',
            ], 404);
        }

        $request->validate([
            'label_alamat' => 'sometimes|required|string|max:30',
            'nama_penerima' => 'sometimes|required|string|max:100',
            'nomor_telepon' => 'sometimes|required|string|max:20',
            'nama_provinsi' => 'sometimes|required|string|max:60',
            'nama_kota' => 'sometimes|required|string|max:60',
            'nama_kecamatan' => 'sometimes|required|string|max:60',
            'kota_id' => 'nullable|integer',
            'kode_pos' => 'sometimes|required|string|max:10',
            'alamat_lengkap' => 'sometimes|required|string',
            'alamat_utama' => 'boolean',
        ]);

        // Petakan field request (Bahasa Indonesia) ke kolom database (Bahasa Inggris)
        $fieldMap = [
            'label_alamat' => 'label',
            'nama_penerima' => 'recipient_name',
            'nomor_telepon' => 'phone',
            'nama_provinsi' => 'province_name',
            'nama_kota' => 'city_name',
            'nama_kecamatan' => 'district_name',
            'kota_id' => 'city_id',
            'kode_pos' => 'postal_code',
            'alamat_lengkap' => 'address_line',
            'alamat_utama' => 'is_primary',
        ];

        $updates = [];
        foreach ($fieldMap as $requestKey => $column) {
            if ($request->has($requestKey)) {
                $updates[$column] = $request->input($requestKey);
            }
        }

        if (! empty($updates['is_primary'])) {
            UserAddress::where('user_id', $request->user()->id)
                ->where('id', '!=', $address->id)
                ->update(['is_primary' => false]);
        }

        $address->update($updates);

        return response()->json([
            'success' => true,
            'message' => 'Alamat berhasil diperbarui.',
            'data' => $address->fresh(),
        ]);
    }

    // PUT /api/addresses/{id}/set-primary
    // Menjadikan sebuah alamat sebagai alamat utama
    public function setPrimary(Request $request, $id)
    {
        $address = UserAddress::where('id', $id)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $address) {
            return response()->json([
                'success' => false,
                'message' => 'Data alamat tidak ditemukan.',
            ], 404);
        }

        // Nonaktifkan alamat utama lain milik user ini
        UserAddress::where('user_id', $request->user()->id)
            ->where('id', '!=', $address->id)
            ->update(['is_primary' => false]);

        $address->update(['is_primary' => true]);

        return response()->json([
            'success' => true,
            'message' => 'Alamat utama berhasil diperbarui.',
            'data' => $address->fresh(),
        ]);
    }

    // DELETE /api/addresses/{id}
    public function destroy(Request $request, $id)
    {
        $address = UserAddress::where('id', $id)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $address) {
            return response()->json([
                'success' => false,
                'message' => 'Alamat tidak ditemukan.',
            ], 404);
        }

        $address->delete();

        return response()->json([
            'success' => true,
            'message' => 'Alamat berhasil dihapus.',
        ]);
    }
}
