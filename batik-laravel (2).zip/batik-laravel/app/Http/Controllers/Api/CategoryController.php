<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    // Mengambil daftar semua kategori beserta produknya
    public function index()
    {
        $categories = Category::with('products')->where('is_active', true)->get();

        return response()->json([
            'status' => 'success',
            'data' => $categories,
        ]);
    }

    // GET /api/categories/{id}
    public function show($id)
    {
        $category = Category::with('products')->findOrFail($id);

        return response()->json([
            'status' => 'success',
            'data' => $category,
        ]);
    }

    // POST /api/categories (Admin)
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:categories,slug',
            'description' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $category = Category::create($request->only('name', 'slug', 'description', 'is_active'));

        return response()->json([
            'status' => 'success',
            'message' => 'Kategori berhasil dibuat.',
            'data' => $category,
        ], 201);
    }

    // PUT /api/categories/{id} (Admin)
    public function update(Request $request, $id)
    {
        $category = Category::findOrFail($id);

        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'slug' => 'sometimes|required|string|max:255|unique:categories,slug,'.$id,
            'description' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $category->update($request->only('name', 'slug', 'description', 'is_active'));

        return response()->json([
            'status' => 'success',
            'message' => 'Kategori berhasil diperbarui.',
            'data' => $category->fresh(),
        ]);
    }

    // DELETE /api/categories/{id} (Admin)
    public function destroy($id)
    {
        $category = Category::with(['products.variants'])->findOrFail($id);

        // products.category_id memakai ON DELETE CASCADE; menghapus kategori
        // akan ikut menghapus produk -> varian -> riwayat pesanan.
        // Karena itu kategori yang masih memiliki produk tidak boleh dihapus.
        if ($category->products->isNotEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Kategori tidak dapat dihapus karena masih memiliki produk. Pindahkan atau hapus produk terlebih dahulu.',
            ], 400);
        }

        $category->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Kategori berhasil dihapus.',
        ]);
    }
}
