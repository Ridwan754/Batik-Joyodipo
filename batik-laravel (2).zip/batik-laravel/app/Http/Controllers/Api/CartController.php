<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CartController extends Controller
{
    private function getCart(int $userId): Cart
    {
        return Cart::firstOrCreate(['user_id' => $userId]);
    }

    // GET /api/cart
    public function index(Request $request)
    {
        $cart = $this->getCart($request->user()->id);
        $cart->load('items.productVariant.product');

        return response()->json([
            'status' => 'success',
            'data' => $cart,
        ]);
    }

    // POST /api/cart/items
    public function addItem(Request $request)
    {
        $data = $request->validate([
            'product_variant_id' => [
                'required',
                'integer',
                'exists:product_variants,id',
            ],
            'quantity' => ['required', 'integer', 'min:1'],
        ]);

        $cart = $this->getCart($request->user()->id);

        $cartItem = DB::transaction(function () use ($data, $cart) {
            $variant = ProductVariant::with('product')
                ->lockForUpdate()
                ->findOrFail($data['product_variant_id']);

            if (! $variant->product || ! $variant->product->is_active) {
                throw ValidationException::withMessages([
                    'product_variant_id' => [
                        'Produk tidak aktif atau tidak tersedia.',
                    ],
                ]);
            }

            $item = CartItem::where('cart_id', $cart->id)
                ->where('product_variant_id', $variant->id)
                ->lockForUpdate()
                ->first();

            $newQuantity = ($item ? $item->quantity : 0)
                + $data['quantity'];

            if ($newQuantity > $variant->stock) {
                throw ValidationException::withMessages([
                    'quantity' => [
                        "Stok tersedia hanya {$variant->stock} item.",
                    ],
                ]);
            }

            if ($item) {
                $item->update(['quantity' => $newQuantity]);

                return $item->fresh('productVariant.product');
            }

            return CartItem::create([
                'cart_id' => $cart->id,
                'product_variant_id' => $variant->id,
                'quantity' => $newQuantity,
            ])->load('productVariant.product');
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Item berhasil ditambahkan ke keranjang.',
            'data' => $cartItem,
        ], 201);
    }

    // PUT /api/cart/items/{id}
    public function updateItem(Request $request, $id)
    {
        $data = $request->validate([
            'quantity' => ['required', 'integer', 'min:1'],
        ]);

        $cart = $this->getCart($request->user()->id);

        $cartItem = DB::transaction(function () use ($cart, $id, $data) {
            $item = CartItem::where('cart_id', $cart->id)
                ->lockForUpdate()
                ->findOrFail($id);

            $variant = ProductVariant::with('product')
                ->lockForUpdate()
                ->findOrFail($item->product_variant_id);

            if (! $variant->product || ! $variant->product->is_active) {
                throw ValidationException::withMessages([
                    'product_variant_id' => [
                        'Produk tidak aktif atau tidak tersedia.',
                    ],
                ]);
            }

            if ($data['quantity'] > $variant->stock) {
                throw ValidationException::withMessages([
                    'quantity' => [
                        "Stok tersedia hanya {$variant->stock} item.",
                    ],
                ]);
            }

            $item->update(['quantity' => $data['quantity']]);

            return $item->fresh('productVariant.product');
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Kuantitas item berhasil diperbarui.',
            'data' => $cartItem,
        ]);
    }

    // DELETE /api/cart/items/{id}
    public function removeItem(Request $request, $id)
    {
        $cart = $this->getCart($request->user()->id);

        $item = CartItem::where('cart_id', $cart->id)
            ->findOrFail($id);

        $item->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Item dihapus dari keranjang.',
        ]);
    }

    // DELETE /api/cart
    public function clearCart(Request $request)
    {
        $cart = $this->getCart($request->user()->id);
        $cart->items()->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Keranjang berhasil dikosongkan.',
        ]);
    }
}
