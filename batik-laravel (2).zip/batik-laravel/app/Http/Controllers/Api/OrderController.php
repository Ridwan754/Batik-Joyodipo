<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderShipment;
use App\Models\ProductVariant;
use App\Models\Voucher;
use App\Models\VoucherUsage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Midtrans\Config;
use Midtrans\Snap;

class OrderController extends Controller
{
    private const ORDER_STATUSES = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];

    /**
     * Membuat pesanan baru dan menghasilkan Snap Token Midtrans
     */
    public function store(Request $request)
    {
        // 1. Validasi Input Data
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_variant_id' => 'required|exists:product_variants,id',
            'items.*.quantity' => 'required|integer|min:1',
            'shipping_cost' => 'required|numeric|min:0',
            'voucher_id' => 'nullable|exists:vouchers,id',
            'voucher_code' => 'nullable|string|max:50',
            'notes' => 'nullable|string|max:500',
        ]);

        try {
            // 2. Transaksi Database (Atomic Operation)
            $order = DB::transaction(function () use ($request) {
                $subtotal = 0;
                $orderItemsData = [];

                foreach ($request->items as $item) {
                    $variant = ProductVariant::with('product')->lockForUpdate()->findOrFail($item['product_variant_id']);

                    // Cek ketersediaan stok
                    if ($variant->stock < $item['quantity']) {
                        throw new \DomainException("Stok untuk varian {$variant->product->name} (Ukuran {$variant->size}) tidak mencukupi.");
                    }

                    $itemSubtotal = $variant->price * $item['quantity'];
                    $subtotal += $itemSubtotal;

                    // Kurangi stok varian produk
                    $variant->decrement('stock', $item['quantity']);

                    // Tampung data snapshot item
                    $orderItemsData[] = [
                        'product_variant_id' => $variant->id,
                        'product_name_snapshot' => $variant->product->name,
                        'variant_size_snapshot' => $variant->size,
                        'sku_snapshot' => $variant->sku,
                        'price' => $variant->price,
                        'quantity' => $item['quantity'],
                        'subtotal' => $itemSubtotal,
                    ];
                }

                // Terapkan voucher bila ada (berbasis voucher_id ATAU voucher_code)
                $discount = 0;
                $voucher = $this->resolveVoucher($request);
                if ($voucher) {
                    $this->assertVoucherUsable($voucher, $subtotal);
                    $discount = $this->calculateDiscount($voucher, $subtotal);
                }

                $grandTotal = max(0, $subtotal + $request->shipping_cost - $discount);

                // Buat record utama Order
                $orderRecord = Order::create([
                    'order_number' => 'ORD-'.strtoupper(Str::random(10)),
                    'user_id' => $request->user()->id,
                    'status' => 'pending',
                    'payment_status' => 'unpaid',
                    'subtotal_amount' => $subtotal,
                    'shipping_cost' => $request->shipping_cost,
                    'grand_total' => $grandTotal,
                    'notes' => $request->notes ?? null,
                ]);

                // Simpan rincian item transaksi
                foreach ($orderItemsData as $itemData) {
                    $orderRecord->items()->create($itemData);
                }

                // Catat pemakaian voucher
                if ($voucher) {
                    VoucherUsage::create([
                        'voucher_id' => $voucher->id,
                        'user_id' => $request->user()->id,
                        'order_id' => $orderRecord->id,
                        'discount_applied' => $discount,
                    ]);

                    Voucher::where('id', $voucher->id)->increment('used_count');
                }

                return $orderRecord;
            });

            // 3. Konfigurasi Midtrans Snap (opsional - pesanan tetap dibuat jika gagal)
            $snapToken = null;
            try {
                Config::$serverKey = config('services.midtrans.server_key');
                Config::$isProduction = config('services.midtrans.is_production');
                Config::$isSanitized = config('services.midtrans.is_sanitized');
                Config::$is3ds = config('services.midtrans.is_3ds');

                $params = [
                    'transaction_details' => [
                        'order_id' => $order->order_number,
                        'gross_amount' => (int) $order->grand_total,
                    ],
                    'customer_details' => [
                        'first_name' => $order->user->name ?? 'Pelanggan Batik',
                        'email' => $order->user->email ?? 'customer@joyodipo.com',
                    ],
                ];

                // Dapatkan Midtrans Snap Token
                $snapToken = Snap::getSnapToken($params);
                $order->update(['snap_token' => $snapToken]);
            } catch (\Exception $e) {
                // Midtrans tidak tersedia / kunci belum dikonfigurasi.
                // Pesanan tetap dibuat agar alur checkout tidak gagal total.
                report($e);
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Pesanan berhasil dibuat.',
                'data' => $order->load('items'),
                'snap_token' => $snapToken,
            ], 201);

        } catch (\DomainException $e) {
            // Aturan bisnis (stok kurang, voucher tidak berlaku, dst.):
            // pesannya memang ditujukan untuk pengguna.
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Throwable $e) {
            // Kesalahan tak terduga (mis. gangguan database): pesan internal
            // tidak boleh bocor ke klien, hanya dicatat ke log.
            report($e);

            return response()->json([
                'status' => 'error',
                'message' => 'Gagal memproses pesanan. Silakan coba lagi nanti.',
            ], 400);
        }
    }

    /**
     * Checkout langsung dari keranjang belanja.
     * Item diambil dari cart user, lalu didelegasikan ke logika store().
     */
    public function storeFromCart(Request $request)
    {
        $request->validate([
            'shipping_cost' => 'required|numeric|min:0',
            'voucher_id' => 'nullable|exists:vouchers,id',
            'voucher_code' => 'nullable|string|max:50',
            'notes' => 'nullable|string|max:500',
        ]);

        $cart = Cart::where('user_id', $request->user()->id)->first();

        if (! $cart || $cart->items->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Keranjang belanja kosong.',
            ], 400);
        }

        // Susun payload items dari isi keranjang
        $items = $cart->items->map(function ($item) {
            return [
                'product_variant_id' => $item->product_variant_id,
                'quantity' => $item->quantity,
            ];
        })->all();

        $request->merge(['items' => $items]);

        $response = $this->store($request);

        // Kosongkan keranjang hanya jika pesanan berhasil dibuat
        if ($response->getStatusCode() === 201) {
            $cart->items()->delete();
        }

        return $response;
    }

    /**
     * Menampilkan semua pesanan milik user yang sedang login
     */
    public function myOrders(Request $request)
    {
        $orders = Order::with('items')
            ->where('user_id', $request->user()->id)
            ->latest()
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $orders,
        ]);
    }

    /**
     * Menampilkan semua pesanan (Admin)
     */
    public function index(Request $request)
    {
        $query = Order::with(['items', 'user'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        return response()->json([
            'status' => 'success',
            'data' => $query->get(),
        ]);
    }

    /**
     * Menampilkan detail pesanan berdasarkan ID atau Order Number
     */
    public function show(Request $request, $identifier)
    {
        $query = Order::with(['items', 'user'])
            ->where(function ($q) use ($identifier) {
                $q->where('id', $identifier)
                    ->orWhere('order_number', $identifier);
            });

        // Pelanggan hanya boleh melihat pesanannya sendiri
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        $order = $query->firstOrFail();

        return response()->json([
            'status' => 'success',
            'data' => $order,
        ]);
    }

    /**
     * Menampilkan detail data pengiriman (resi) milik sebuah pesanan
     * Akses: pemilik pesanan atau admin
     */
    public function shipment(Request $request, $identifier)
    {
        $query = Order::with('shipment')
            ->where(function ($q) use ($identifier) {
                $q->where('id', $identifier)
                    ->orWhere('order_number', $identifier);
            });

        // Pelanggan hanya boleh melihat pengiriman pesanannya sendiri
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        $order = $query->first();

        if (! $order) {
            return response()->json([
                'status' => 'error',
                'message' => 'Pesanan tidak ditemukan.',
            ], 404);
        }

        if (! $order->shipment) {
            return response()->json([
                'status' => 'error',
                'message' => 'Data pengiriman untuk pesanan ini belum tersedia.',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => $order->shipment,
        ]);
    }

    /**
     * Membatalkan pesanan milik user (hanya status pending)
     */
    public function cancel(Request $request, $id)
    {
        $order = Order::with('items')
            ->where('id', $id)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $order) {
            return response()->json([
                'status' => 'error',
                'message' => 'Pesanan tidak ditemukan.',
            ], 404);
        }

        if ($order->status !== 'pending') {
            return response()->json([
                'status' => 'error',
                'message' => 'Hanya pesanan dengan status pending yang dapat dibatalkan.',
            ], 400);
        }

        DB::transaction(function () use ($order) {
            $order->restoreStock();
            $order->update(['status' => 'cancelled']);
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Pesanan berhasil dibatalkan.',
            'data' => $order->fresh('items'),
        ]);
    }

    /**
     * Memperbarui status pesanan (Admin)
     */
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:'.implode(',', self::ORDER_STATUSES),
        ]);

        $order = Order::with('items.productVariant')->findOrFail($id);
        $previousStatus = $order->status;
        $newStatus = $request->status;

        // Idempotent: tidak ada perubahan
        if ($previousStatus === $newStatus) {
            return response()->json([
                'status' => 'success',
                'message' => 'Status pesanan tidak berubah.',
                'data' => $order->fresh('items'),
            ]);
        }

        // Pesanan yang sudah selesai bersifat final
        if ($previousStatus === 'completed') {
            return response()->json([
                'status' => 'error',
                'message' => 'Pesanan yang sudah selesai tidak dapat diubah statusnya.',
            ], 400);
        }

        try {
            DB::transaction(function () use ($order, $newStatus, $previousStatus) {
                if ($newStatus === 'cancelled') {
                    // Stok dikembalikan saat pesanan dibatalkan
                    $order->restoreStock();
                } elseif ($previousStatus === 'cancelled') {
                    // Pesanan yang tadinya dibatalkan diaktifkan kembali:
                    // stok harus dipesan ulang agar tidak terjadi overselling.
                    $this->reserveStock($order);
                }

                $order->update(['status' => $newStatus]);
            });
        } catch (\DomainException $e) {
            // Aturan bisnis: stok tidak cukup untuk mengaktifkan kembali pesanan.
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Throwable $e) {
            // Jangan bocorkan detail kesalahan internal ke klien.
            report($e);

            return response()->json([
                'status' => 'error',
                'message' => 'Gagal memperbarui status pesanan. Silakan coba lagi nanti.',
            ], 400);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Status pesanan berhasil diperbarui.',
            'data' => $order->fresh('items'),
        ]);
    }

    /**
     * Membuat/memperbarui data pengiriman (resi) sebuah pesanan (Admin).
     * Sekaligus mengubah status pesanan menjadi "shipped".
     */
    public function storeShipment(Request $request, $id)
    {
        $data = $request->validate([
            'courier_code' => 'required|string|max:50',
            'courier_service' => 'required|string|max:100',
            'tracking_number' => 'nullable|string|max:100',
            'recipient_name' => 'required|string|max:255',
            'phone_number' => 'required|string|max:30',
            'full_address' => 'required|string',
        ]);

        $order = Order::findOrFail($id);

        if ($order->status === 'cancelled') {
            return response()->json([
                'status' => 'error',
                'message' => 'Pesanan yang sudah dibatalkan tidak dapat dikirim.',
            ], 400);
        }

        $shipment = DB::transaction(function () use ($order, $data) {
            // Satu pesanan punya satu data pengiriman (upsert)
            $shipment = OrderShipment::updateOrCreate(
                ['order_id' => $order->id],
                $data
            );

            // Otomatis tandai pesanan sebagai sudah dikirim
            if (in_array($order->status, ['pending', 'processing'], true)) {
                $order->update(['status' => 'shipped']);
            }

            return $shipment;
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Data pengiriman berhasil disimpan dan pesanan ditandai sebagai dikirim.',
            'data' => [
                'shipment' => $shipment,
                'order' => $order->fresh('items'),
            ],
        ]);
    }

    /**
     * Menentukan voucher dari permintaan checkout.
     * Mendukung voucher_id maupun voucher_code; bila keduanya dikirim, voucher_code diprioritaskan.
     */
    private function resolveVoucher(Request $request): ?Voucher
    {
        if ($request->filled('voucher_code')) {
            $voucher = Voucher::where('code', $request->voucher_code)->first();

            if (! $voucher) {
                throw new \DomainException('Kode voucher tidak valid.');
            }

            return $voucher;
        }

        if ($request->filled('voucher_id')) {
            $voucher = Voucher::find($request->voucher_id);

            if (! $voucher) {
                throw new \DomainException('Voucher tidak ditemukan.');
            }

            return $voucher;
        }

        return null;
    }

    /**
     * Pesan ulang stok seluruh item pesanan (dipakai saat pesanan yang
     * sebelumnya dibatalkan diaktifkan kembali). Gagal bila stok tidak cukup.
     */
    private function reserveStock(Order $order): void
    {
        foreach ($order->items as $item) {
            $variant = ProductVariant::lockForUpdate()->find($item->product_variant_id);

            if (! $variant) {
                throw new \DomainException('Varian produk pada pesanan ini sudah tidak tersedia.');
            }

            if ($variant->stock < $item->quantity) {
                throw new \DomainException("Stok varian {$variant->sku} tidak mencukupi untuk mengaktifkan kembali pesanan ini.");
            }

            $variant->decrement('stock', $item->quantity);
        }
    }

    /**
     * Pastikan voucher masih valid untuk subtotal tertentu.
     */
    private function assertVoucherUsable(Voucher $voucher, float $subtotal): void
    {
        $now = now();

        if (! $voucher->is_active) {
            throw new \DomainException('Voucher tidak aktif.');
        }

        if ($voucher->starts_at && $now->lt($voucher->starts_at)) {
            throw new \DomainException('Voucher belum berlaku.');
        }

        if ($voucher->expires_at && $now->gt($voucher->expires_at)) {
            throw new \DomainException('Voucher sudah kedaluwarsa.');
        }

        if ($voucher->usage_limit && $voucher->used_count >= $voucher->usage_limit) {
            throw new \DomainException('Kuota voucher sudah habis.');
        }

        if ($subtotal < $voucher->min_order_amount) {
            throw new \DomainException('Minimal belanja untuk voucher ini belum terpenuhi.');
        }
    }

    /**
     * Hitung nominal diskon voucher.
     */
    private function calculateDiscount(Voucher $voucher, float $subtotal): float
    {
        if ($voucher->type === 'fixed') {
            return (float) $voucher->discount_amount;
        }

        $discount = ($subtotal * $voucher->discount_amount) / 100;

        if ($voucher->max_discount_amount && $discount > $voucher->max_discount_amount) {
            $discount = (float) $voucher->max_discount_amount;
        }

        return (float) $discount;
    }
}
