<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // POST /api/register
    public function register(Request $request)
    {
        $request->validate([
            'nama_pengguna' => 'required|string|max:100',
            'email' => 'required|string|email|max:150|unique:users,email',
            'kata_sandi' => 'required|string|min:8|confirmed',
            'nomor_telepon' => 'nullable|string|max:20',
        ]);

        // 'role' bukan lagi mass-assignable, jadi ditetapkan eksplisit oleh
        // sisi server. Pengguna yang mendaftar selalu menjadi 'pelanggan',
        // tidak peduli field apa pun yang disertakan dalam payload.
        $user = User::forceCreate([
            'name' => $request->nama_pengguna,
            'email' => $request->email,
            'password' => Hash::make($request->kata_sandi),
            'phone' => $request->nomor_telepon ?? null,
            'role' => 'pelanggan',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Registrasi berhasil.',
            'data' => $user,
        ], 201);
    }

    // POST /api/login
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'kata_sandi' => 'required|string',
        ]);

        $user = User::where('email', $request->email)->first();

        if (! $user || ! Hash::check($request->kata_sandi, $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Kredensial login tidak valid.',
            ], 401);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Login berhasil.',
            'data' => [
                'token' => $token,
                'token_type' => 'Bearer',
                'user' => $user,
            ],
        ]);
    }

    // GET /api/me
    public function me(Request $request)
    {
        return response()->json([
            'success' => true,
            'message' => 'Profil berhasil diambil.',
            'data' => $request->user(),
        ]);
    }

    // PUT /api/profile
    // Memperbarui data profil (nama, telepon, email, kata sandi)
    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'nama_pengguna' => 'sometimes|required|string|max:100',
            'email' => 'sometimes|required|string|email|max:150|unique:users,email,'.$user->id,
            'nomor_telepon' => 'nullable|string|max:20',
            'kata_sandi_lama' => 'nullable|required_with:kata_sandi|string',
            'kata_sandi' => 'nullable|string|min:8|confirmed',
        ]);

        // Jika ingin ganti kata sandi, kata sandi lama wajib cocok
        if ($request->filled('kata_sandi')) {
            if (! $request->filled('kata_sandi_lama') || ! Hash::check($request->kata_sandi_lama, $user->password)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Kata sandi lama tidak sesuai.',
                ], 400);
            }
        }

        if ($request->has('nama_pengguna')) {
            $user->name = $request->nama_pengguna;
        }
        if ($request->has('email')) {
            $user->email = $request->email;
        }
        if ($request->has('nomor_telepon')) {
            $user->phone = $request->nomor_telepon;
        }
        if ($request->filled('kata_sandi')) {
            $user->password = Hash::make($request->kata_sandi);
        }

        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'Profil berhasil diperbarui.',
            'data' => $user->fresh(),
        ]);
    }

    // POST /api/logout
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Berhasil keluar.',
        ]);
    }
}
