<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\WebhookLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Midtrans\Config;
use Midtrans\Notification;

class PaymentWebhookController extends Controller
{
    /**
     * Menerima notifikasi pembayaran dari Midtrans.
     * Notifikasi diverifikasi dua lapis: validasi signature_key secara lokal,
     * lalu pengambilan status resmi dari API Midtrans (via library Notification)
     * sebelum memengaruhi data pesanan.
     */
    public function handle(Request $request)
    {
        // 1. Konfigurasi Midtrans (via config agar aman saat config:cache)
        $serverKey = config('services.midtrans.server_key');
        Config::$serverKey = $serverKey;
        Config::$isProduction = config('services.midtrans.is_production');

        // 2. Validasi signature notifikasi (order_id + status_code + gross_amount + serverKey)
        $payload = $request->all();
        $orderNumber = $payload['order_id'] ?? null;
        $statusCode = $payload['status_code'] ?? null;
        $grossAmount = $payload['gross_amount'] ?? null;
        $signature = $payload['signature_key'] ?? null;

        if (! $serverKey || ! $orderNumber || ! $signature || $statusCode === null || $grossAmount === null) {
            return response()->json([
                'status' => 'error',
                'message' => 'Notifikasi pembayaran tidak valid.',
            ], 400);
        }

        $expectedSignature = hash('sha512', $orderNumber.$statusCode.$grossAmount.$serverKey);

        if (! hash_equals($expectedSignature, (string) $signature)) {
            return response()->json([
                'status' => 'error',
                'message' => 'Notifikasi pembayaran tidak valid.',
            ], 400);
        }

        // 3. Ambil status resmi dari Midtrans untuk notifikasi yang lolos validasi
        try {
            $notif = new Notification;
            $transactionStatus = $notif->transaction_status;
            $type = $notif->payment_type;
            $orderId = $notif->order_id;
            $fraudStatus = $notif->fraud_status;
        } catch (\Exception $e) {
            report($e);

            return response()->json([
                'status' => 'error',
                'message' => 'Notifikasi pembayaran tidak valid.',
            ], 400);
        }

        // 4. Catat webhook masuk
        WebhookLog::create([
            'event_id' => $notif->transaction_id ?? 'EVT-'.time(),
            'source' => 'midtrans',
            'event_type' => $transactionStatus,
            'order_number' => $orderId,
            'payload' => json_encode($payload),
            'status' => '200_ok',
        ]);

        // 5. Cari Order berdasarkan order_number
        $order = Order::with('items.productVariant')
            ->where('order_number', $orderId)
            ->first();

        if (! $order) {
            return response()->json(['message' => 'Order tidak ditemukan'], 404);
        }

        // 6. Terapkan perubahan status pembayaran secara atomik
        DB::transaction(function () use ($order, $transactionStatus, $type, $fraudStatus) {
            $order->applyMidtransStatus($transactionStatus, $type, $fraudStatus);
        });

        return response()->json(['status' => 'success', 'message' => 'Notification processed successfully']);
    }
}
