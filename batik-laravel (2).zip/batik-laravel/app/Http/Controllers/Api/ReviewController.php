<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductReview;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    // GET /api/products/{slug}/reviews (Publik)
    // Mengambil daftar ulasan beserta rata-rata rating sebuah produk
    public function index($slug)
    {
        $product = Product::where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        $reviews = ProductReview::with('user:id,name')
            ->where('product_id', $product->id)
            ->orderBy('created_at', 'desc')
            ->get();

        $averageRating = round((float) $reviews->avg('rating'), 1);

        return response()->json([
            'success' => true,
            'data' => [
                'product_id' => $product->id,
                'total_reviews' => $reviews->count(),
                'average_rating' => $averageRating,
                'reviews' => $reviews,
            ],
        ]);
    }

    // POST /api/orders/{id}/reviews (Login)
    // Membuat ulasan untuk pesanan yang sudah selesai (completed)
    public function store(Request $request, $orderId)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $order = Order::with('items.productVariant')
            ->where('id', $orderId)
            ->where('user_id', $request->user()->id)
            ->first();

        if (! $order) {
            return response()->json([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan.',
            ], 404);
        }

        if ($order->status !== 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Ulasan hanya dapat diberikan untuk pesanan yang sudah selesai.',
            ], 400);
        }

        // Pastikan produk memang bagian dari pesanan tersebut
        // (order_items hanya menyimpan product_variant_id, jadi telusuri lewat varian)
        $orderedProductIds = $order->items
            ->map(fn ($item) => $item->productVariant?->product_id)
            ->filter()
            ->unique();
        if (! $orderedProductIds->contains((int) $request->product_id)) {
            return response()->json([
                'success' => false,
                'message' => 'Produk tidak ditemukan dalam pesanan ini.',
            ], 400);
        }

        // Cegah duplikasi: satu user hanya boleh mengulas satu produk sekali
        // (sesuai unique constraint product_id + user_id di migration)
        $exists = ProductReview::where('user_id', $request->user()->id)
            ->where('product_id', $request->product_id)
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'Anda sudah memberikan ulasan untuk produk ini pada pesanan ini.',
            ], 400);
        }

        $review = ProductReview::create([
            'user_id' => $request->user()->id,
            'product_id' => $request->product_id,
            'order_id' => $order->id,
            'rating' => $request->rating,
            'comment' => $request->comment,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Ulasan berhasil ditambahkan.',
            'data' => $review,
        ], 201);
    }

    // DELETE /api/reviews/{id} (Login) - hanya milik sendiri atau admin
    public function destroy(Request $request, $id)
    {
        $review = ProductReview::find($id);

        if (! $review) {
            return response()->json([
                'success' => false,
                'message' => 'Ulasan tidak ditemukan.',
            ], 404);
        }

        if ($review->user_id !== $request->user()->id && $request->user()->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Anda tidak memiliki hak akses untuk menghapus ulasan ini.',
            ], 403);
        }

        $review->delete();

        return response()->json([
            'success' => true,
            'message' => 'Ulasan berhasil dihapus.',
        ]);
    }
}
