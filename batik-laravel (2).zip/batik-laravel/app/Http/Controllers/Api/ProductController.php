<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // Mengambil daftar semua produk beserta kategori & variannya
    public function index()
    {
        $products = Product::with(['category', 'variants'])
            ->where('is_active', true)
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $products,
        ]);
    }

    // Mengambil detail 1 produk berdasarkan slug
    public function show($slug)
    {
        $product = Product::with(['category', 'variants'])
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        return response()->json([
            'status' => 'success',
            'data' => $product,
        ]);
    }

    // GET /api/products/search?q=&category_id=&min_price=&max_price=
    // Pencarian & filter produk (hanya produk aktif)
    public function search(Request $request)
    {
        $request->validate([
            'q' => 'nullable|string|max:100',
            'category_id' => 'nullable|integer|exists:categories,id',
            'min_price' => 'nullable|numeric|min:0',
            'max_price' => 'nullable|numeric|min:0',
        ]);

        $query = Product::with(['category:id,name,slug', 'variants'])
            ->where('is_active', true);

        if ($request->filled('q')) {
            $keyword = $request->q;
            $query->where(function ($q) use ($keyword) {
                $q->where('name', 'like', "%{$keyword}%")
                    ->orWhere('description', 'like', "%{$keyword}%");
            });
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // Harga produk ditentukan oleh varian, jadi filter lewat relasi variants
        if ($request->filled('min_price')) {
            $query->whereHas('variants', function ($q) use ($request) {
                $q->where('price', '>=', $request->min_price);
            });
        }

        if ($request->filled('max_price')) {
            $query->whereHas('variants', function ($q) use ($request) {
                $q->where('price', '<=', $request->max_price);
            });
        }

        $products = $query->latest()->get();

        return response()->json([
            'status' => 'success',
            'data' => $products,
        ]);
    }

    // GET /api/admin/products (Admin)
    // daftar produk untuk pengelolaan: termasuk produk non-aktif
    public function adminIndex(Request $request)
    {
        $request->validate([
            'q' => 'nullable|string|max:100',
            'category_id' => 'nullable|integer|exists:categories,id',
            'is_active' => 'nullable|boolean',
        ]);

        $query = Product::with(['category:id,name,slug', 'variants']);

        if ($request->filled('q')) {
            $keyword = $request->q;
            $query->where(function ($q) use ($keyword) {
                $q->where('name', 'like', "%{$keyword}%")
                    ->orWhere('description', 'like', "%{$keyword}%");
            });
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('is_active') && $request->is_active !== null) {
            $query->where('is_active', filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN));
        }

        return response()->json([
            'status' => 'success',
            'data' => $query->latest()->get(),
        ]);
    }

    // POST /api/products (Admin)
    public function store(Request $request)
    {
        $data = $request->validate([
            'category_id' => 'required|integer|exists:categories,id',
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:products,slug',
            'gender_type' => 'nullable|in:men,women,unisex',
            'description' => 'nullable|string',
            'material_info' => 'nullable|string',
            'is_featured' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
        ]);

        $product = Product::create($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Produk berhasil dibuat.',
            'data' => $product->load(['category:id,name,slug', 'variants']),
        ], 201);
    }

    // PUT /api/products/{id} (Admin)
    // menerima ID numerik agar konsisten dengan resource admin lain (kategori)
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $data = $request->validate([
            'category_id' => 'sometimes|required|integer|exists:categories,id',
            'name' => 'sometimes|required|string|max:255',
            'slug' => 'sometimes|required|string|max:255|unique:products,slug,'.$id,
            'gender_type' => 'nullable|in:men,women,unisex',
            'description' => 'nullable|string',
            'material_info' => 'nullable|string',
            'is_featured' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
        ]);

        $product->update($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Produk berhasil diperbarui.',
            'data' => $product->fresh(['category:id,name,slug', 'variants']),
        ]);
    }

    // DELETE /api/products/{id} (Admin)
    public function destroy($id)
    {
        $product = Product::with('variants')->findOrFail($id);

        // order_items.product_variant_id memakai ON DELETE CASCADE,
        // jadi produk yang sudah pernah dipesan tidak boleh dihapus.
        $isUsed = OrderItem::whereIn('product_variant_id', $product->variants->pluck('id'))->exists();

        if ($isUsed) {
            return response()->json([
                'status' => 'error',
                'message' => 'Produk tidak dapat dihapus karena sudah menjadi bagian dari riwayat pesanan. Ubah menjadi non-aktif (is_active=false) sebagai gantinya.',
            ], 400);
        }

        // Varian ikut terhapus otomatis (FK ON DELETE CASCADE)
        $product->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Produk berhasil dihapus.',
        ]);
    }
}
