<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Voucher;
use App\Models\VoucherUsage;
use Carbon\Carbon;
use Illuminate\Http\Request;

class VoucherController extends Controller
{
    // GET /api/vouchers/available (Customer)
    public function available()
    {
        $now = Carbon::now();

        $vouchers = Voucher::where('is_active', true)
            ->where(function ($query) use ($now) {
                $query->whereNull('starts_at')->orWhere('starts_at', '<=', $now);
            })
            ->where(function ($query) use ($now) {
                $query->whereNull('expires_at')->orWhere('expires_at', '>=', $now);
            })
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $vouchers,
        ]);
    }

    // POST /api/vouchers/validate (Customer)
    public function validateVoucher(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'subtotal' => 'required|numeric|min:0',
        ]);

        $voucher = Voucher::where('code', $request->code)->where('is_active', true)->first();

        if (! $voucher) {
            return response()->json(['status' => 'error', 'message' => 'Kode voucher tidak valid.'], 404);
        }

        $now = Carbon::now();
        if ($voucher->starts_at && $now->lt($voucher->starts_at)) {
            return response()->json(['status' => 'error', 'message' => 'Voucher belum berlaku.'], 400);
        }

        if ($voucher->expires_at && $now->gt($voucher->expires_at)) {
            return response()->json(['status' => 'error', 'message' => 'Voucher sudah kedaluwarsa.'], 400);
        }

        if ($voucher->usage_limit && $voucher->used_count >= $voucher->usage_limit) {
            return response()->json(['status' => 'error', 'message' => 'Kuota voucher sudah habis.'], 400);
        }

        if ($request->subtotal < $voucher->min_order_amount) {
            return response()->json([
                'status' => 'error',
                'message' => 'Minimal belanja untuk voucher ini adalah Rp '.number_format($voucher->min_order_amount, 0, ',', '.'),
            ], 400);
        }

        // Hitung Potongan Diskon
        $discount = 0;
        if ($voucher->type === 'fixed') {
            $discount = $voucher->discount_amount;
        } else {
            $discount = ($request->subtotal * $voucher->discount_amount) / 100;
            if ($voucher->max_discount_amount && $discount > $voucher->max_discount_amount) {
                $discount = $voucher->max_discount_amount;
            }
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Voucher berhasil diterapkan.',
            'data' => [
                'voucher_id' => $voucher->id,
                'code' => $voucher->code,
                'discount_amount' => $discount,
            ],
        ]);
    }

    // GET /api/voucher-usages/me (Customer)
    public function myUsages(Request $request)
    {
        $usages = VoucherUsage::with('voucher')
            ->where('user_id', $request->user()->id)
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $usages,
        ]);
    }

    // GET /api/vouchers (Admin)
    public function index()
    {
        return response()->json([
            'status' => 'success',
            'data' => Voucher::all(),
        ]);
    }

    // POST /api/vouchers (Admin)
    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => 'required|string|unique:vouchers,code|max:50',
            'name' => 'required|string|max:255',
            'type' => 'required|in:fixed,percentage',
            'discount_amount' => 'required|numeric|min:0',
            'min_order_amount' => 'nullable|numeric|min:0',
            'max_discount_amount' => 'nullable|numeric|min:0',
            'usage_limit' => 'nullable|integer|min:1',
            'starts_at' => 'nullable|date',
            'expires_at' => 'nullable|date|after_or_equal:starts_at',
        ]);

        $voucher = Voucher::create($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Voucher berhasil dibuat.',
            'data' => $voucher,
        ], 201);
    }

    // GET /api/vouchers/{id} (Admin)
    public function show($id)
    {
        $voucher = Voucher::with('usages')->findOrFail($id);

        return response()->json([
            'status' => 'success',
            'data' => $voucher,
        ]);
    }

    // PUT /api/vouchers/{id} (Admin)
    public function update(Request $request, $id)
    {
        $voucher = Voucher::findOrFail($id);

        $data = $request->validate([
            'code' => 'sometimes|required|string|unique:vouchers,code,'.$id.'|max:50',
            'name' => 'sometimes|required|string|max:255',
            'type' => 'sometimes|required|in:fixed,percentage',
            'discount_amount' => 'sometimes|required|numeric|min:0',
            'min_order_amount' => 'nullable|numeric|min:0',
            'max_discount_amount' => 'nullable|numeric|min:0',
            'usage_limit' => 'nullable|integer|min:1',
            'is_active' => 'nullable|boolean',
            'starts_at' => 'nullable|date',
            'expires_at' => 'nullable|date|after_or_equal:starts_at',
        ]);

        $voucher->update($data);

        return response()->json([
            'status' => 'success',
            'message' => 'Voucher berhasil diperbarui.',
            'data' => $voucher->fresh(),
        ]);
    }

    // DELETE /api/vouchers/{id} (Admin)
    public function destroy($id)
    {
        $voucher = Voucher::with('usages')->findOrFail($id);

        // voucher_usages mereferensikan voucher; hapus aman hanya bila belum dipakai
        if ($voucher->usages->isNotEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Voucher tidak dapat dihapus karena sudah pernah digunakan. Nonaktifkan voucher (is_active=false) sebagai gantinya.',
            ], 400);
        }

        $voucher->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Voucher berhasil dihapus.',
        ]);
    }
}
