<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    // GET /api/dashboard (Admin)
    // Statistik ringkas untuk dashboard admin
    public function index(Request $request)
    {
        $totalRevenue = Order::where('payment_status', 'paid')
            ->sum('grand_total');

        $ordersByStatus = Order::select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status');

        $recentOrders = Order::with('user:id,name,email')
            ->latest()
            ->take(10)
            ->get([
                'id', 'order_number', 'user_id',
                'status', 'payment_status', 'grand_total',
                'created_at',
            ]);

        return response()->json([
            'success' => true,
            'data' => [
                'total_products' => Product::count(),
                'total_customers' => User::where('role', 'pelanggan')->count(),
                'total_orders' => Order::count(),
                'total_revenue' => (float) $totalRevenue,
                'orders_by_status' => $ordersByStatus,
                'recent_orders' => $recentOrders,
            ],
        ]);
    }
}
