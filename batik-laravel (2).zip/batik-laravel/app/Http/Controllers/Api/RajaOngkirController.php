<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class RajaOngkirController extends Controller
{
    public function checkCost(Request $request)
    {
        $request->validate([
            'destination_city_id' => 'required|numeric',
            'weight_g' => 'required|numeric|min:1',
            'courier' => 'required|string|in:jne,pos,tiki',
        ]);

        try {
            $response = Http::timeout(15)->withHeaders([
                'key' => config('services.rajaongkir.key'),
            ])->post('https://api.rajaongkir.com/starter/cost', [
                'origin' => config('services.rajaongkir.origin_city_id'), // ID Kota asal pengiriman
                'destination' => $request->destination_city_id,
                'weight' => $request->weight_g,
                'courier' => $request->courier,
            ]);

            return response()->json($response->json(), $response->successful() ? 200 : 502);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Gagal menghubungi layanan ongkos kirim. Silakan coba lagi nanti.',
            ], 502);
        }
    }
}
