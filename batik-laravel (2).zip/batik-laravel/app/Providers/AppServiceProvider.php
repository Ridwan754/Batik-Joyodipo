<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->configureRateLimiting();
    }

    /**
     * Batas laju percobaan autentikasi untuk mencegah brute force dan spam akun.
     */
    private function configureRateLimiting(): void
    {
        // Login dibatasi per kombinasi email + IP, bukan IP saja,
        // agar penyerang dari satu IP tidak mudah mengunci akun korban.
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)
                ->by(Str::lower((string) $request->input('email')).'|'.$request->ip())
                ->response(fn (Request $request, array $headers) => $this->tooManyAttemptsResponse($headers));
        });

        // Registrasi cukup dibatasi per IP.
        RateLimiter::for('register', function (Request $request) {
            return Limit::perMinute(3)
                ->by((string) $request->ip())
                ->response(fn (Request $request, array $headers) => $this->tooManyAttemptsResponse($headers));
        });
    }

    /**
     * Respons 429 yang formatnya konsisten dengan kontrak respons JSON API.
     */
    private function tooManyAttemptsResponse(array $headers): Response
    {
        return response()->json([
            'success' => false,
            'status' => 'error',
            'message' => 'Terlalu banyak percobaan. Silakan tunggu beberapa saat lalu coba lagi.',
        ], 429, $headers);
    }
}
