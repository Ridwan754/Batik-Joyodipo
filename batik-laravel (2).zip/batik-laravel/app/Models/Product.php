<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'is_featured' => 'boolean',
        'is_active' => 'boolean',
    ];

    // Relasi: Produk milik satu Kategori
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // Relasi: Satu Produk punya banyak Varian (Ukuran/Stok/Harga)
    public function variants()
    {
        return $this->hasMany(ProductVariant::class);
    }

    // Relasi: Satu Produk punya banyak Ulasan (Review)
    public function reviews()
    {
        return $this->hasMany(ProductReview::class);
    }
}
