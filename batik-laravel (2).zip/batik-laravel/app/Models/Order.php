<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relasi: Satu pesanan punya satu data pengiriman (resi/kurir)
    public function shipment()
    {
        return $this->hasOne(OrderShipment::class);
    }

    /**
     * Kembalikan stok seluruh item pesanan ke inventori.
     */
    public function restoreStock(): void
    {
        foreach ($this->items as $item) {
            if ($item->productVariant) {
                $item->productVariant->increment('stock', $item->quantity);
            }
        }
    }

    /**
     * Sinkronkan status pesanan dengan status transaksi Midtrans.
     * Tidak pernah menurunkan pesanan yang sudah dikirim/selesai, dan
     * mengembalikan stok sekali saja saat pesanan dibatalkan/kedaluwarsa.
     *
     * @param  string|null  $transactionStatus  capture|settlement|pending|deny|cancel|expire
     * @param  string|null  $type  Contoh: credit_card
     * @param  string|null  $fraudStatus  accept|challenge|deny
     */
    public function applyMidtransStatus(?string $transactionStatus, ?string $type = null, ?string $fraudStatus = null): void
    {
        switch ($transactionStatus) {
            case 'capture':
                // Kartu kredit dengan fraud challenge ditahan sampai ditinjau
                if ($type === 'credit_card' && $fraudStatus === 'challenge') {
                    if ($this->payment_status !== 'paid') {
                        $this->payment_status = 'unpaid';
                    }
                    break;
                }
                $this->markPaid();

                break;

            case 'settlement':
                $this->markPaid();

                break;

            case 'pending':
                // Masih menunggu pembayaran: jangan turunkan pesanan yang sudah dibayar
                if ($this->payment_status !== 'paid') {
                    $this->payment_status = 'unpaid';
                }

                break;

            case 'deny':
            case 'cancel':
            case 'expire':
                // Barang yang sudah dikirim/selesai tidak dibatalkan otomatis
                if (! in_array($this->status, ['shipped', 'completed', 'cancelled'], true)) {
                    $this->restoreStock();
                    $this->status = 'cancelled';
                }
                $this->payment_status = $transactionStatus === 'expire' ? 'expired' : 'failed';

                break;

            default:
                // Status di luar cakupan: tidak mengubah apa pun
                return;
        }

        $this->save();
    }

    /**
     * Tandai pesanan sudah dibayar dan pindahkan ke processing
     * hanya bila belum melewati tahap tersebut.
     */
    private function markPaid(): void
    {
        $this->payment_status = 'paid';

        if ($this->status === 'pending') {
            $this->status = 'processing';
        }
    }
}
