﻿# Batik Joyodipo - API Postman Collection

This folder contains:
- batik-joyodipo-api.postman_collection.json
- batik-joyodipo-api.postman_environment.json
- README.md

## Import

1. Open Postman → Import → drag the JSON files here.
2. Select the environment `Batik Joyodipo - Local`.
3. Set the credential variables in that environment (see below).
4. Run Login (Customer) or Login (Admin) requests — tokens auto-save to env.

## Credentials

Passwords are **not stored in this repository**. Set them in your local Postman
environment (`Batik Joyodipo - Local`) before running login:

| Variable | Purpose | Default value |
|---|---|---|
| `customer_email` | Customer login email | `qa.pelanggan@example.com` |
| `customer_password` | Customer login password | *(empty — set locally)* |
| `admin_email` | Admin login email | `admin@joyodipo.example.com` |
| `admin_password` | Admin login password | *(empty — set locally)* |

- Only email addresses are committed; passwords are left blank on purpose.
- Never commit passwords, password hashes, or `token`/`admin_token` values.
- To create a customer account, set `customer_password` (min 8 characters) and send
  the `Register` request. It posts to `{{baseUrl}}/register` using
  `test+{{$timestamp}}@example.com` and `{{customer_password}}` for both password fields.
- `Login (Customer)` and `Login (Admin)` read their email/password from these variables.
- The login sample that previously hard-coded a customer password has been removed;
  that credential was stale and no longer matched any account.

## Notes

- Bearer auth uses `{{token}}` (collection-level). Admin folders override to `{{admin_token}}`.
- Midtrans/RajaOngkir keys are placeholders in `.env`; external calls may fail gracefully until real keys are set.
- Seeder data: Product Variant ID 1 (Batik Parang Gurdo M), Category 1 (Batik Tulis).
- The `POST /api/payments/webhook` request requires a valid Midtrans `signature_key`
  (`sha512(order_id + status_code + gross_amount + serverKey)`); the placeholder in the
  collection will be rejected with HTTP 400 by design.
