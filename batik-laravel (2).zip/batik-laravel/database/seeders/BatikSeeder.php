<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Database\Seeder;

class BatikSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Buat Kategori
        $kategoriTulis = Category::create([
            'name' => 'Batik Tulis',
            'slug' => 'batik-tulis',
            'description' => 'Koleksi Batik Tulis Mahakarya Joyodipo',
            'is_active' => true,
        ]);

        // 2. Buat Produk
        $produk = Product::create([
            'category_id' => $kategoriTulis->id,
            'name' => 'Batik Tulis Motif Parang Gurdo',
            'slug' => 'batik-tulis-motif-parang-gurdo',
            'gender_type' => 'men',
            'description' => 'Kain Batik Tulis halus motif Parang Gurdo dengan pewarna alam.',
            'material_info' => 'Sutra Katun Premium',
            'is_featured' => true,
            'is_active' => true,
        ]);

        // 3. Buat Varian Produk
        ProductVariant::create([
            'product_id' => $produk->id,
            'sku' => 'BT-PRG-M',
            'size' => 'M',
            'chest_size_cm' => 104,
            'body_length_cm' => 72,
            'price' => 750000,
            'stock' => 10,
            'weight_g' => 500,
        ]);

        ProductVariant::create([
            'product_id' => $produk->id,
            'sku' => 'BT-PRG-L',
            'size' => 'L',
            'chest_size_cm' => 108,
            'body_length_cm' => 74,
            'price' => 750000,
            'stock' => 5,
            'weight_g' => 500,
        ]);
    }
}
