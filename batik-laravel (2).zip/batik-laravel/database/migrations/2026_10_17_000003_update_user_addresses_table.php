<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_addresses', function (Blueprint $table) {
            $table->string('label', 30)->nullable()->after('user_id');
            $table->unsignedBigInteger('city_id')->nullable()->change();
            $table->string('province_name', 60)->nullable()->after('city_name');
            $table->string('district_name', 60)->nullable()->after('province_name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_addresses', function (Blueprint $table) {
            $table->dropColumn(['label', 'province_name', 'district_name']);
            $table->unsignedBigInteger('city_id')->nullable(false)->change();
        });
    }
};
