<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductReview;
use App\Models\ProductVariant;
use App\Models\User;
use App\Models\Voucher;
use App\Models\VoucherUsage;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * Menutup celah cakupan endpoint API yang belum diuji oleh
 * ApiEndpointFlowTest, ApiSecurityTest, OrderLifecycleTest, dan AdminApiSmokeTest:
 * CRUD kategori admin, filter pencarian/daftar, daftar & pemakaian voucher,
 * pembatalan pesanan oleh pemilik, hapus ulasan (pemilik/admin), show & update alamat,
 * hapus item keranjang, dan cek ongkos kirim (RajaOngkir) dengan HTTP dipalsukan.
 */
class ApiEndpointCoverageTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(string $role = 'pelanggan'): User
    {
        // 'role' bukan mass-assignable; peran ditetapkan lewat forceCreate untuk pengujian.
        return User::forceCreate([
            'name' => ucfirst($role),
            'email' => $role.'-'.bin2hex(random_bytes(6)).'@example.test',
            'password' => 'secret123',
            'role' => $role,
        ]);
    }

    private function tokenFor(User $user): string
    {
        // Guard auth menyimpan user hasil resolve selama satu test berjalan,
        // sehingga guard di-reset setiap kali berganti token/identitas.
        $this->app['auth']->forgetGuards();

        return $user->createToken('test')->plainTextToken;
    }

    /** @return array{0: Category, 1: Product, 2: ProductVariant} */
    private function createCatalog(int $stock = 5): array
    {
        $category = Category::create([
            'name' => 'Batik Pria',
            'slug' => 'batik-pria-'.bin2hex(random_bytes(3)),
        ]);
        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Klasik',
            'slug' => 'batik-klasik-'.bin2hex(random_bytes(3)),
            'gender_type' => 'men',
            'is_active' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-'.bin2hex(random_bytes(4)),
            'size' => 'L',
            'price' => 150000,
            'stock' => $stock,
        ]);

        return [$category, $product, $variant];
    }

    private function createProductWithVariant(Category $category, string $name, int $price): Product
    {
        $product = Product::create([
            'category_id' => $category->id,
            'name' => $name,
            'slug' => Str::slug($name).'-'.bin2hex(random_bytes(3)),
            'gender_type' => 'unisex',
            'is_active' => true,
        ]);

        ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-'.bin2hex(random_bytes(4)),
            'size' => 'L',
            'price' => $price,
            'stock' => 3,
        ]);

        return $product;
    }

    private function createOrder(User $user, ProductVariant $variant, string $status = 'pending'): Order
    {
        $order = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $user->id,
            'status' => $status,
            'payment_status' => 'unpaid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ]);

        OrderItem::create([
            'order_id' => $order->id,
            'product_variant_id' => $variant->id,
            'product_name_snapshot' => 'Batik Klasik',
            'variant_size_snapshot' => 'L',
            'sku_snapshot' => $variant->sku,
            'price' => 150000,
            'quantity' => 1,
            'subtotal' => 150000,
        ]);

        return $order;
    }

    private function addressPayload(array $overrides = []): array
    {
        return array_merge([
            'label_alamat' => 'Rumah',
            'nama_penerima' => 'Budi',
            'nomor_telepon' => '081234567890',
            'nama_provinsi' => 'DKI Jakarta',
            'nama_kota' => 'Jakarta',
            'nama_kecamatan' => 'Menteng',
            'kode_pos' => '10310',
            'alamat_lengkap' => 'Jl. Merdeka No. 1',
        ], $overrides);
    }

    // -----------------------------------------------------------------
    // Kategori (Admin)
    // -----------------------------------------------------------------

    public function test_admin_can_create_and_update_category(): void
    {
        $token = $this->tokenFor($this->makeUser('admin'));

        $categoryId = $this->withToken($token)->postJson('/api/categories', [
            'name' => 'Batik Wanita',
            'slug' => 'batik-wanita',
            'description' => 'Koleksi batik wanita',
        ])->assertStatus(201)
            ->assertJsonPath('status', 'success')
            ->json('data.id');

        $this->assertDatabaseHas('categories', ['id' => $categoryId, 'name' => 'Batik Wanita']);

        $this->withToken($token)->putJson("/api/categories/{$categoryId}", [
            'name' => 'Batik Wanita Premium',
        ])->assertOk()
            ->assertJsonPath('data.name', 'Batik Wanita Premium');

        $this->assertDatabaseHas('categories', ['id' => $categoryId, 'name' => 'Batik Wanita Premium']);

        // Slug duplikat ditolak validasi.
        $this->withToken($token)->postJson('/api/categories', [
            'name' => 'Duplikat',
            'slug' => 'batik-wanita',
        ])->assertStatus(422)->assertJsonValidationErrors('slug');
    }

    // -----------------------------------------------------------------
    // Voucher
    // -----------------------------------------------------------------

    public function test_admin_voucher_index_lists_all_vouchers_and_is_admin_only(): void
    {
        Voucher::create([
            'code' => 'AKTIF10',
            'name' => 'Aktif',
            'type' => 'percentage',
            'discount_amount' => 10,
            'is_active' => true,
        ]);
        Voucher::create([
            'code' => 'NONAKTIF',
            'name' => 'Nonaktif',
            'type' => 'fixed',
            'discount_amount' => 5000,
            'is_active' => false,
        ]);

        $this->withToken($this->tokenFor($this->makeUser('admin')))
            ->getJson('/api/vouchers')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->assertJsonCount(2, 'data');

        $this->withToken($this->tokenFor($this->makeUser()))
            ->getJson('/api/vouchers')
            ->assertForbidden();
    }

    public function test_voucher_usages_are_scoped_to_the_authenticated_customer(): void
    {
        $voucher = Voucher::create([
            'code' => 'HEMAT10',
            'name' => 'Diskon 10%',
            'type' => 'percentage',
            'discount_amount' => 10,
            'is_active' => true,
        ]);

        $owner = $this->makeUser();
        $stranger = $this->makeUser();
        [, , $variant] = $this->createCatalog();

        $ownerOrder = $this->createOrder($owner, $variant);
        $strangerOrder = $this->createOrder($stranger, $variant);

        VoucherUsage::create([
            'voucher_id' => $voucher->id,
            'user_id' => $owner->id,
            'order_id' => $ownerOrder->id,
            'discount_applied' => 10000,
        ]);
        VoucherUsage::create([
            'voucher_id' => $voucher->id,
            'user_id' => $stranger->id,
            'order_id' => $strangerOrder->id,
            'discount_applied' => 10000,
        ]);

        $usages = $this->withToken($this->tokenFor($owner))
            ->getJson('/api/voucher-usages/me')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->json('data');

        // Hanya pemakaian milik user yang login, lengkap dengan relasi voucher.
        $this->assertCount(1, $usages);
        $this->assertSame($voucher->id, $usages[0]['voucher_id']);
        $this->assertArrayHasKey('voucher', $usages[0]);
    }

    // -----------------------------------------------------------------
    // Pesanan: pembatalan oleh pemilik
    // -----------------------------------------------------------------

    public function test_customer_can_cancel_own_pending_order_and_stock_is_restored(): void
    {
        [, , $variant] = $this->createCatalog(stock: 5);
        $owner = $this->makeUser();
        $order = $this->createOrder($owner, $variant, status: 'pending');
        $token = $this->tokenFor($owner);

        // Simulasi stok yang sudah terpotong saat checkout.
        $variant->decrement('stock', 1);
        $this->assertSame(4, $variant->fresh()->stock);

        $this->withToken($token)->postJson("/api/orders/{$order->id}/cancel")
            ->assertOk()
            ->assertJsonPath('data.status', 'cancelled');

        $this->assertSame('cancelled', $order->fresh()->status);
        $this->assertSame(5, $variant->fresh()->stock);

        // Pesanan yang bukan pending tidak dapat dibatalkan.
        $processing = $this->createOrder($owner, $variant, status: 'processing');
        $this->withToken($token)->postJson("/api/orders/{$processing->id}/cancel")
            ->assertStatus(400)
            ->assertJsonPath('status', 'error');

        $this->assertSame('processing', $processing->fresh()->status);
    }

    // -----------------------------------------------------------------
    // Ulasan: hapus oleh pemilik & admin
    // -----------------------------------------------------------------

    public function test_review_can_be_deleted_by_owner_and_by_admin(): void
    {
        [, $product] = $this->createCatalog();
        $owner = $this->makeUser();

        $ownedReview = ProductReview::create([
            'user_id' => $owner->id,
            'product_id' => $product->id,
            'rating' => 5,
            'comment' => 'Bagus',
        ]);

        $this->withToken($this->tokenFor($owner))
            ->deleteJson("/api/reviews/{$ownedReview->id}")
            ->assertOk();

        $this->assertDatabaseMissing('product_reviews', ['id' => $ownedReview->id]);

        // Admin dapat menghapus ulasan milik pengguna lain.
        $otherReview = ProductReview::create([
            'user_id' => $owner->id,
            'product_id' => $product->id,
            'rating' => 4,
            'comment' => 'Cukup',
        ]);

        $this->withToken($this->tokenFor($this->makeUser('admin')))
            ->deleteJson("/api/reviews/{$otherReview->id}")
            ->assertOk();

        $this->assertDatabaseMissing('product_reviews', ['id' => $otherReview->id]);
    }

    public function test_review_store_rejects_second_review_for_the_same_product(): void
    {
        [, $product, $variant] = $this->createCatalog();
        $user = $this->makeUser();
        $order = $this->createOrder($user, $variant, status: 'completed');
        $token = $this->tokenFor($user);

        $this->withToken($token)->postJson("/api/orders/{$order->id}/reviews", [
            'product_id' => $product->id,
            'rating' => 4,
        ])->assertStatus(201);

        $this->withToken($token)->postJson("/api/orders/{$order->id}/reviews", [
            'product_id' => $product->id,
            'rating' => 5,
        ])->assertStatus(400)
            ->assertJsonPath('message', 'Anda sudah memberikan ulasan untuk produk ini pada pesanan ini.');
    }

    public function test_review_store_returns_404_for_another_users_order(): void
    {
        [, $product, $variant] = $this->createCatalog();
        $owner = $this->makeUser();
        $stranger = $this->makeUser();
        $order = $this->createOrder($owner, $variant, status: 'completed');

        $this->withToken($this->tokenFor($stranger))->postJson("/api/orders/{$order->id}/reviews", [
            'product_id' => $product->id,
            'rating' => 5,
        ])->assertNotFound();

        $this->assertDatabaseCount('product_reviews', 0);
    }

    // -----------------------------------------------------------------
    // Alamat: show & update oleh pemilik
    // -----------------------------------------------------------------

    public function test_address_can_be_shown_and_updated_by_owner(): void
    {
        $token = $this->tokenFor($this->makeUser());

        $addressId = $this->withToken($token)->postJson('/api/addresses', $this->addressPayload())
            ->assertStatus(201)->json('data.id');

        $this->withToken($token)->getJson("/api/addresses/{$addressId}")
            ->assertOk()
            ->assertJsonPath('data.id', $addressId)
            ->assertJsonPath('data.recipient_name', 'Budi');

        // Field request (Bahasa Indonesia) dipetakan ke kolom database.
        $this->withToken($token)->putJson("/api/addresses/{$addressId}", [
            'label_alamat' => 'Kantor',
            'nama_kota' => 'Bandung',
            'alamat_lengkap' => 'Jl. Asia Afrika No. 5',
        ])->assertOk()
            ->assertJsonPath('data.label', 'Kantor')
            ->assertJsonPath('data.city_name', 'Bandung')
            ->assertJsonPath('data.address_line', 'Jl. Asia Afrika No. 5');

        $this->assertDatabaseHas('user_addresses', [
            'id' => $addressId,
            'label' => 'Kantor',
            'city_name' => 'Bandung',
        ]);
    }

    // -----------------------------------------------------------------
    // Keranjang: hapus item oleh pemilik
    // -----------------------------------------------------------------

    public function test_cart_item_can_be_removed_by_owner(): void
    {
        [, , $variant] = $this->createCatalog(stock: 5);
        $token = $this->tokenFor($this->makeUser());

        $this->withToken($token)->postJson('/api/cart/items', [
            'product_variant_id' => $variant->id,
            'quantity' => 2,
        ])->assertStatus(201);

        $itemId = $this->withToken($token)->getJson('/api/cart')
            ->assertOk()->json('data.items.0.id');

        $this->withToken($token)->deleteJson("/api/cart/items/{$itemId}")
            ->assertOk()
            ->assertJsonPath('status', 'success');

        $this->withToken($token)->getJson('/api/cart')
            ->assertOk()
            ->assertJsonCount(0, 'data.items');
    }

    // -----------------------------------------------------------------
    // Pencarian & filter produk
    // -----------------------------------------------------------------

    public function test_product_search_filters_by_category_and_price_range(): void
    {
        $categoryA = Category::create(['name' => 'Kategori A', 'slug' => 'kategori-a']);
        $categoryB = Category::create(['name' => 'Kategori B', 'slug' => 'kategori-b']);

        $cheap = $this->createProductWithVariant($categoryA, 'Batik Murah', 50000);
        $pricey = $this->createProductWithVariant($categoryA, 'Batik Mahal', 500000);
        $other = $this->createProductWithVariant($categoryB, 'Batik Lain', 50000);

        $byCategory = $this->getJson('/api/products/search?category_id='.$categoryA->id)
            ->assertOk()->json('data.*.id');
        $this->assertEqualsCanonicalizing([$cheap->id, $pricey->id], $byCategory);

        $byMaxPrice = $this->getJson('/api/products/search?max_price=100000')
            ->assertOk()->json('data.*.id');
        $this->assertContains($cheap->id, $byMaxPrice);
        $this->assertContains($other->id, $byMaxPrice);
        $this->assertNotContains($pricey->id, $byMaxPrice);
    }

    public function test_admin_order_index_filters_by_status(): void
    {
        [, , $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $pending = $this->createOrder($customer, $variant, status: 'pending');
        $processing = $this->createOrder($customer, $variant, status: 'processing');

        $ids = $this->withToken($this->tokenFor($this->makeUser('admin')))
            ->getJson('/api/orders?status=pending')
            ->assertOk()->json('data.*.id');

        $this->assertContains($pending->id, $ids);
        $this->assertNotContains($processing->id, $ids);
    }

    // -----------------------------------------------------------------
    // Checkout langsung (POST /orders) — happy path
    // -----------------------------------------------------------------

    public function test_store_order_creates_item_snapshot_and_decrements_stock(): void
    {
        [, $product, $variant] = $this->createCatalog(stock: 5);
        $user = $this->makeUser();

        $this->withToken($this->tokenFor($user))->postJson('/api/orders', [
            'items' => [['product_variant_id' => $variant->id, 'quantity' => 2]],
            'shipping_cost' => 15000,
            'notes' => 'Tolong dibungkus rapi',
        ])->assertStatus(201)->assertJsonPath('status', 'success');

        $order = Order::latest('id')->firstOrFail();

        $this->assertSame($user->id, $order->user_id);
        $this->assertSame('pending', $order->status);
        $this->assertEquals(300000, $order->subtotal_amount);
        $this->assertEquals(315000, $order->grand_total);
        $this->assertSame(3, $variant->fresh()->stock);

        $item = $order->items->first();
        $this->assertSame($product->name, $item->product_name_snapshot);
        $this->assertSame(2, $item->quantity);
        $this->assertSame('L', $item->variant_size_snapshot);
    }

    // -----------------------------------------------------------------
    // Ongkos kirim (RajaOngkir) — HTTP eksternal dipalsukan
    // -----------------------------------------------------------------

    public function test_shipping_cost_returns_provider_response(): void
    {
        Http::preventStrayRequests();
        Http::fake([
            'https://api.rajaongkir.com/starter/cost' => Http::response([
                'rajaongkir' => [
                    'status' => ['code' => 200],
                    'results' => [['name' => 'jne', 'costs' => []]],
                ],
            ], 200),
        ]);

        $token = $this->tokenFor($this->makeUser());

        $this->withToken($token)->postJson('/api/shipping/cost', [
            'destination_city_id' => 151,
            'weight_g' => 1000,
            'courier' => 'jne',
        ])->assertOk()->assertJsonPath('rajaongkir.status.code', 200);

        Http::assertSentCount(1);
    }

    public function test_shipping_cost_returns_502_when_provider_responds_with_error(): void
    {
        Http::preventStrayRequests();
        Http::fake([
            'https://api.rajaongkir.com/starter/cost' => Http::response([
                'rajaongkir' => ['status' => ['code' => 400, 'description' => 'Bad request']],
            ], 500),
        ]);

        $token = $this->tokenFor($this->makeUser());

        $this->withToken($token)->postJson('/api/shipping/cost', [
            'destination_city_id' => 151,
            'weight_g' => 1000,
            'courier' => 'jne',
        ])->assertStatus(502);
    }

    public function test_shipping_cost_returns_502_when_provider_is_unreachable(): void
    {
        Http::preventStrayRequests();
        Http::fake([
            'https://api.rajaongkir.com/starter/cost' => fn () => throw new ConnectionException('Koneksi gagal'),
        ]);

        $token = $this->tokenFor($this->makeUser());

        $this->withToken($token)->postJson('/api/shipping/cost', [
            'destination_city_id' => 151,
            'weight_g' => 1000,
            'courier' => 'jne',
        ])->assertStatus(502)
            ->assertJsonPath('status', 'error')
            ->assertJsonPath('message', 'Gagal menghubungi layanan ongkos kirim. Silakan coba lagi nanti.');
    }

    // -----------------------------------------------------------------
    // Validasi registrasi & login
    // -----------------------------------------------------------------

    public function test_register_rejects_duplicate_email(): void
    {
        $payload = [
            'nama_pengguna' => 'Pelanggan Ganda',
            'email' => 'ganda@example.test',
            'kata_sandi' => 'rahasia123',
            'kata_sandi_confirmation' => 'rahasia123',
        ];

        $this->postJson('/api/register', $payload)->assertStatus(201);

        $this->postJson('/api/register', $payload)
            ->assertStatus(422)
            ->assertJsonValidationErrors('email');
    }

    public function test_login_requires_email_and_password(): void
    {
        $this->postJson('/api/login', [])
            ->assertStatus(422)
            ->assertJsonValidationErrors(['email', 'kata_sandi']);
    }
}
