<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use App\Models\VoucherUsage;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Smoke test endpoint admin yang baru ditambahkan:
 * produk, varian, pengiriman/resi, voucher, checkout, dan otorisasi.
 */
class AdminApiSmokeTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(string $role): User
    {
        // 'role' bukan mass-assignable lagi (mencegah eskalasi hak akses),
        // sehingga peran ditetapkan lewat forceCreate khusus untuk pengujian.
        return User::forceCreate([
            'name' => ucfirst($role),
            'email' => $role.'-'.bin2hex(random_bytes(6)).'@example.test',
            'password' => 'secret123',
            'role' => $role,
        ]);
    }

    private function tokenFor(User $user): string
    {
        // Guard auth menyimpan user hasil resolve selama satu test berjalan,
        // sehingga guard di-reset setiap kali berganti token/identitas.
        $this->app['auth']->forgetGuards();

        return $user->createToken('test')->plainTextToken;
    }

    /** @return array{0: Product, 1: ProductVariant} */
    private function createCatalog(): array
    {
        $category = Category::create(['name' => 'Batik Pria', 'slug' => 'batik-pria']);
        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Klasik',
            'slug' => 'batik-klasik',
            'gender_type' => 'men',
            'is_active' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-001',
            'size' => 'L',
            'price' => 150000,
            'stock' => 5,
        ]);

        return [$product, $variant];
    }

    private function createOrder(User $user, ProductVariant $variant, string $status = 'pending'): Order
    {
        $order = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $user->id,
            'status' => $status,
            'payment_status' => 'unpaid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ]);

        OrderItem::create([
            'order_id' => $order->id,
            'product_variant_id' => $variant->id,
            'product_name_snapshot' => 'Batik Klasik',
            'variant_size_snapshot' => 'L',
            'sku_snapshot' => $variant->sku,
            'price' => 150000,
            'quantity' => 1,
            'subtotal' => 150000,
        ]);

        return $order;
    }

    public function test_customer_cannot_access_admin_endpoints(): void
    {
        [$product, $variant] = $this->createCatalog();
        $customer = $this->makeUser('pelanggan');
        $order = $this->createOrder($customer, $variant);
        $token = $this->tokenFor($customer);

        $this->withToken($token)->getJson('/api/admin/products')->assertForbidden();
        $this->withToken($token)->postJson('/api/products', [])->assertForbidden();
        $this->withToken($token)->putJson("/api/products/{$product->id}", [])->assertForbidden();
        $this->withToken($token)->deleteJson("/api/products/{$product->id}")->assertForbidden();
        $this->withToken($token)->postJson('/api/variants', [])->assertForbidden();
        $this->withToken($token)->putJson("/api/variants/{$variant->id}", [])->assertForbidden();
        $this->withToken($token)->deleteJson("/api/variants/{$variant->id}")->assertForbidden();
        $this->withToken($token)->postJson('/api/vouchers', [])->assertForbidden();
        $this->withToken($token)->getJson('/api/vouchers/1')->assertForbidden();
        $this->withToken($token)->putJson('/api/vouchers/1', [])->assertForbidden();
        $this->withToken($token)->deleteJson('/api/vouchers/1')->assertForbidden();
        $this->withToken($token)->postJson("/api/orders/{$order->id}/shipment", [])->assertForbidden();
        $this->withToken($token)->patchJson("/api/orders/{$order->id}/status", [])->assertForbidden();
    }

    public function test_admin_product_crud(): void
    {
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);
        $category = Category::create(['name' => 'Batik Wanita', 'slug' => 'batik-wanita']);

        $productId = $this->withToken($token)->postJson('/api/products', [
            'category_id' => $category->id,
            'name' => 'Batik Modern',
            'slug' => 'batik-modern',
            'gender_type' => 'unisex',
        ])->assertStatus(201)->json('data.id');

        // Nonaktifkan produk (Product tidak memakai boolean cast, jadi nilainya 0/1)
        $updateResponse = $this->withToken($token)->putJson("/api/products/{$productId}", [
            'is_active' => false,
        ])->assertOk();
        $this->assertEmpty($updateResponse->json('data.is_active'));

        // Daftar admin tetap menampilkan produk non-aktif
        $adminIds = $this->withToken($token)->getJson('/api/admin/products')
            ->assertOk()->json('data.*.id');
        $this->assertContains($productId, $adminIds);

        // Katalog publik menyembunyikan produk non-aktif
        $publicIds = $this->getJson('/api/products')->assertOk()->json('data.*.id');
        $this->assertNotContains($productId, $publicIds);

        // Hapus produk yang belum punya riwayat pesanan
        $this->withToken($token)->deleteJson("/api/products/{$productId}")->assertOk();
        $this->assertDatabaseMissing('products', ['id' => $productId]);
    }

    public function test_product_delete_is_blocked_when_order_history_exists(): void
    {
        [$product, $variant] = $this->createCatalog();
        $admin = $this->makeUser('admin');
        $customer = $this->makeUser('pelanggan');
        $this->createOrder($customer, $variant);
        $token = $this->tokenFor($admin);

        $this->withToken($token)->deleteJson("/api/products/{$product->id}")->assertStatus(400);
        $this->assertDatabaseHas('products', ['id' => $product->id]);
    }

    public function test_admin_variant_crud_supports_product_scoped_store(): void
    {
        [$product, $variant] = $this->createCatalog();
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        // Product-scoped: product_id diambil dari path
        $scopedId = $this->withToken($token)->postJson("/api/products/{$product->id}/variants", [
            'sku' => 'SKU-002',
            'size' => 'M',
            'price' => 120000,
            'stock' => 3,
        ])->assertStatus(201)->json('data.id');
        $listed = collect($this->withToken($token)->getJson('/api/variants?product_id='.$product->id)
            ->assertOk()->json('data'));
        $created = $listed->firstWhere('id', $scopedId);
        $this->assertNotNull($created);
        $this->assertEquals($product->id, $created['product_id']);

        // Flat store (tanpa product_id di path)
        $flatId = $this->withToken($token)->postJson('/api/variants', [
            'product_id' => $product->id,
            'sku' => 'SKU-003',
            'size' => 'XL',
            'price' => 130000,
            'stock' => 2,
        ])->assertStatus(201)->json('data.id');

        // Update
        $updated = $this->withToken($token)->putJson("/api/variants/{$variant->id}", [
            'price' => 175000,
        ])->assertOk()->json('data.price');
        $this->assertEquals(175000, $updated);

        // Varian dengan riwayat pesanan tidak boleh dihapus
        $customer = $this->makeUser('pelanggan');
        $this->createOrder($customer, $variant);
        $this->withToken($token)->deleteJson("/api/variants/{$variant->id}")->assertStatus(400);
        $this->assertDatabaseHas('product_variants', ['id' => $variant->id]);

        // Varian tanpa riwayat pesanan bisa dihapus
        $this->withToken($token)->deleteJson("/api/variants/{$flatId}")->assertOk();
        $this->assertDatabaseMissing('product_variants', ['id' => $flatId]);
    }

    public function test_admin_shipment_upsert_marks_order_as_shipped(): void
    {
        [$product, $variant] = $this->createCatalog();
        $customer = $this->makeUser('pelanggan');
        $order = $this->createOrder($customer, $variant);
        $admin = $this->makeUser('admin');
        $adminToken = $this->tokenFor($admin);

        $this->withToken($adminToken)->postJson("/api/orders/{$order->id}/shipment", [
            'courier_code' => 'jne',
            'courier_service' => 'REG',
            'tracking_number' => 'JNE-001',
            'recipient_name' => 'Budi',
            'phone_number' => '081234567890',
            'full_address' => 'Jl. Merdeka No. 1, Jakarta',
        ])->assertOk();

        $this->assertDatabaseHas('order_shipments', [
            'order_id' => $order->id,
            'tracking_number' => 'JNE-001',
        ]);
        $this->assertSame('shipped', $order->fresh()->status);

        // Pemilik pesanan dapat membaca resinya
        $customerToken = $this->tokenFor($customer);
        $this->withToken($customerToken)->getJson("/api/orders/{$order->id}/shipment")->assertOk();
    }

    public function test_order_show_is_scoped_to_owner(): void
    {
        [$product, $variant] = $this->createCatalog();
        $owner = $this->makeUser('pelanggan');
        $stranger = $this->makeUser('pelanggan');
        $admin = $this->makeUser('admin');
        $order = $this->createOrder($owner, $variant);

        $this->withToken($this->tokenFor($stranger))->getJson("/api/orders/{$order->id}")->assertNotFound();
        $this->withToken($this->tokenFor($owner))->getJson("/api/orders/{$order->id}")->assertOk();
        $this->withToken($this->tokenFor($admin))->getJson("/api/orders/{$order->id}")->assertOk();

        // Sama halnya untuk data pengiriman
        $this->withToken($this->tokenFor($stranger))->getJson("/api/orders/{$order->id}/shipment")->assertNotFound();
    }

    public function test_admin_voucher_crud_and_delete_guard(): void
    {
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        $voucherId = $this->withToken($token)->postJson('/api/vouchers', [
            'code' => 'HEMAT10',
            'name' => 'Diskon 10%',
            'type' => 'percentage',
            'discount_amount' => 10,
            'min_order_amount' => 50000,
        ])->assertStatus(201)->json('data.id');

        $this->withToken($token)->getJson("/api/vouchers/{$voucherId}")->assertOk();

        $this->withToken($token)->putJson("/api/vouchers/{$voucherId}", [
            'is_active' => false,
        ])->assertOk()->assertJsonPath('data.is_active', false);

        // Voucher yang belum dipakai bisa dihapus
        $this->withToken($token)->deleteJson("/api/vouchers/{$voucherId}")->assertOk();
        $this->assertDatabaseMissing('vouchers', ['id' => $voucherId]);

        // Voucher yang sudah dipakai tidak boleh dihapus
        $usedId = $this->withToken($token)->postJson('/api/vouchers', [
            'code' => 'VIP20',
            'name' => 'Diskon 20%',
            'type' => 'fixed',
            'discount_amount' => 20000,
        ])->assertStatus(201)->json('data.id');

        [$product, $variant] = $this->createCatalog();
        $customer = $this->makeUser('pelanggan');
        $order = $this->createOrder($customer, $variant);
        VoucherUsage::create([
            'voucher_id' => $usedId,
            'user_id' => $customer->id,
            'order_id' => $order->id,
            'discount_applied' => 20000,
        ]);

        $this->withToken($token)->deleteJson("/api/vouchers/{$usedId}")->assertStatus(400);
        $this->assertDatabaseHas('vouchers', ['id' => $usedId]);
    }

    public function test_checkout_from_cart_and_voucher_code_handling(): void
    {
        [, $variant] = $this->createCatalog();
        $customer = $this->makeUser('pelanggan');
        $token = $this->tokenFor($customer);

        // Checkout dengan keranjang kosong harus ditolak
        $this->withToken($token)->postJson('/api/orders/from-cart', [
            'shipping_cost' => 10000,
        ])->assertStatus(400)->assertJsonPath('message', 'Keranjang belanja kosong.');

        // voucher_code diterima dan divalidasi (kode tidak valid -> transaksi dibatalkan)
        $this->withToken($token)->postJson('/api/orders', [
            'items' => [['product_variant_id' => $variant->id, 'quantity' => 1]],
            'shipping_cost' => 10000,
            'voucher_code' => 'TIDAK-ADA',
        ])->assertStatus(400)->assertJsonPath('message', 'Kode voucher tidak valid.');

        // Transaksi dibatalkan: tidak ada pesanan tersimpan
        $this->assertDatabaseCount('orders', 0);
    }
}
