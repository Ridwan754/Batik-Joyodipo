<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductReview;
use App\Models\ProductVariant;
use App\Models\User;
use App\Models\UserAddress;
use App\Models\Wishlist;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\RateLimiter;
use Tests\TestCase;

/**
 * Uji prioritas keamanan backend Batik Joyodipo:
 * eskalasi hak akses lewat mass assignment, rate limit autentikasi,
 * kebocoran pesan error internal saat checkout, dan pembatasan kepemilikan data.
 */
class ApiSecurityTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(string $role = 'pelanggan'): User
    {
        // 'role' bukan mass-assignable lagi, jadi ditetapkan eksplisit di sini.
        return User::forceCreate([
            'name' => ucfirst($role),
            'email' => $role.'-'.bin2hex(random_bytes(6)).'@example.test',
            'password' => 'secret123',
            'role' => $role,
        ]);
    }

    private function tokenFor(User $user): string
    {
        $this->app['auth']->forgetGuards();

        return $user->createToken('test')->plainTextToken;
    }

    /** @return array{0: Product, 1: ProductVariant} */
    private function createCatalog(int $stock = 5): array
    {
        $category = Category::create(['name' => 'Batik Pria', 'slug' => 'batik-pria']);
        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Klasik',
            'slug' => 'batik-klasik',
            'gender_type' => 'men',
            'is_active' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-'.bin2hex(random_bytes(4)),
            'size' => 'L',
            'price' => 150000,
            'stock' => $stock,
        ]);

        return [$product, $variant];
    }

    public function test_register_cannot_escalate_role_to_admin(): void
    {
        // Payload jahat: mencoba menyetel peran admin saat pendaftaran.
        $this->postJson('/api/register', [
            'nama_pengguna' => 'Penyusup',
            'email' => 'penyusup@example.test',
            'kata_sandi' => 'rahasia123',
            'kata_sandi_confirmation' => 'rahasia123',
            'role' => 'admin',
            'is_admin' => true,
        ])->assertStatus(201);

        // Peran tetap 'pelanggan' (nilai default database), bukan admin.
        $user = User::where('email', 'penyusup@example.test')->firstOrFail();
        $this->assertSame('pelanggan', $user->role);

        // Token hasil login tidak membuka endpoint admin.
        $token = $this->postJson('/api/login', [
            'email' => 'penyusup@example.test',
            'kata_sandi' => 'rahasia123',
        ])->assertOk()->json('data.token');

        $this->withToken($token)->getJson('/api/dashboard')->assertForbidden();
        $this->withToken($token)->getJson('/api/admin/products')->assertForbidden();
    }

    public function test_profile_update_cannot_change_role(): void
    {
        $user = $this->makeUser();
        $token = $this->tokenFor($user);

        $this->withToken($token)->putJson('/api/profile', [
            'nama_pengguna' => 'Nama Baru',
            'role' => 'admin',
        ])->assertOk();

        $this->assertSame('pelanggan', $user->fresh()->role);
        $this->assertSame('Nama Baru', $user->fresh()->name);
    }

    public function test_login_is_rate_limited_after_five_attempts(): void
    {
        $payload = [
            'email' => 'korbanserangan@example.test',
            'kata_sandi' => 'tebakan-salah',
        ];

        for ($attempt = 1; $attempt <= 5; $attempt++) {
            $this->postJson('/api/login', $payload)->assertStatus(401);
        }

        $this->postJson('/api/login', $payload)
            ->assertStatus(429)
            ->assertJsonPath('success', false)
            ->assertJsonPath('status', 'error');

        $this->assertNotNull(RateLimiter::limiter('login'));
    }

    public function test_register_is_rate_limited_after_three_attempts(): void
    {
        for ($attempt = 1; $attempt <= 3; $attempt++) {
            // Payload kosong -> 422, tetapi percobaan tetap terhitung.
            $this->postJson('/api/register', [])->assertStatus(422);
        }

        $this->postJson('/api/register', [])->assertStatus(429);
    }

    public function test_checkout_does_not_leak_internal_error_details(): void
    {
        [, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $token = $this->tokenFor($customer);

        // Sengaja memicu kesalahan tak terduga di dalam transaksi checkout.
        Order::creating(function (): void {
            throw new \RuntimeException('KUNCI_RAHASIA_INTERNAL_DATABASE');
        });

        $response = $this->withToken($token)->postJson('/api/orders', [
            'items' => [['product_variant_id' => $variant->id, 'quantity' => 1]],
            'shipping_cost' => 10000,
        ]);

        $response->assertStatus(400);
        $this->assertStringNotContainsString(
            'KUNCI_RAHASIA_INTERNAL_DATABASE',
            $response->getContent()
        );
        $this->assertSame(
            'Gagal memproses pesanan. Silakan coba lagi nanti.',
            $response->json('message')
        );

        $this->assertDatabaseCount('orders', 0);
    }

    public function test_checkout_business_rule_messages_are_still_returned(): void
    {
        [, $variant] = $this->createCatalog(stock: 1);
        $customer = $this->makeUser();
        $token = $this->tokenFor($customer);

        $response = $this->withToken($token)->postJson('/api/orders', [
            'items' => [['product_variant_id' => $variant->id, 'quantity' => 10]],
            'shipping_cost' => 10000,
        ]);

        $response->assertStatus(400);
        $this->assertStringContainsString('tidak mencukupi', $response->json('message'));

        // Transaksi dibatalkan: stok tidak berubah dan tidak ada pesanan tersimpan.
        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(1, $variant->fresh()->stock);
    }

    public function test_addresses_are_scoped_to_owner(): void
    {
        $owner = $this->makeUser();
        $stranger = $this->makeUser();

        $addressId = UserAddress::create([
            'user_id' => $owner->id,
            'label' => 'Rumah',
            'recipient_name' => 'Budi',
            'phone' => '081234567890',
            'address_line' => 'Jl. Merdeka No. 1',
            'city_name' => 'Jakarta',
            'province_name' => 'DKI Jakarta',
            'district_name' => 'Menteng',
            'postal_code' => '10310',
            'is_primary' => true,
        ])->id;

        $strangerToken = $this->tokenFor($stranger);

        $this->withToken($strangerToken)->getJson("/api/addresses/{$addressId}")->assertNotFound();
        $this->withToken($strangerToken)->putJson("/api/addresses/{$addressId}", [
            'alamat_lengkap' => 'Jalan curian',
        ])->assertNotFound();
        $this->withToken($strangerToken)->putJson("/api/addresses/{$addressId}/set-primary")->assertNotFound();
        $this->withToken($strangerToken)->deleteJson("/api/addresses/{$addressId}")->assertNotFound();
        $this->assertDatabaseHas('user_addresses', ['id' => $addressId]);

        // Daftar alamat milik stranger tidak ikut menampilkan alamat owner.
        $this->withToken($strangerToken)->getJson('/api/addresses')
            ->assertOk()
            ->assertJsonMissing(['id' => $addressId]);
    }

    public function test_wishlist_item_can_only_be_deleted_by_owner(): void
    {
        [$product] = $this->createCatalog();
        $owner = $this->makeUser();
        $stranger = $this->makeUser();

        $wishlistId = Wishlist::create([
            'user_id' => $owner->id,
            'product_id' => $product->id,
        ])->id;

        $this->withToken($this->tokenFor($stranger))
            ->deleteJson("/api/wishlist/{$wishlistId}")
            ->assertNotFound();

        $this->assertDatabaseHas('wishlists', ['id' => $wishlistId]);

        $this->withToken($this->tokenFor($owner))
            ->deleteJson("/api/wishlist/{$wishlistId}")
            ->assertOk();

        $this->assertDatabaseMissing('wishlists', ['id' => $wishlistId]);
    }

    public function test_cart_item_can_only_be_changed_by_owner(): void
    {
        [, $variant] = $this->createCatalog();
        $owner = $this->makeUser();
        $stranger = $this->makeUser();

        $this->withToken($this->tokenFor($owner))->postJson('/api/cart/items', [
            'product_variant_id' => $variant->id,
            'quantity' => 1,
        ])->assertStatus(201);

        $cartItem = $this->withToken($this->tokenFor($owner))
            ->getJson('/api/cart')
            ->assertOk()
            ->json('data.items.0');

        $strangerToken = $this->tokenFor($stranger);

        $this->withToken($strangerToken)
            ->putJson("/api/cart/items/{$cartItem['id']}", ['quantity' => 99])
            ->assertNotFound();

        $this->withToken($strangerToken)
            ->deleteJson("/api/cart/items/{$cartItem['id']}")
            ->assertNotFound();

        // Kuantitas tetap seperti milik owner dan item tidak terhapus.
        $this->withToken($this->tokenFor($owner))
            ->getJson('/api/cart')
            ->assertOk()
            ->assertJsonPath('data.items.0.quantity', 1);
    }

    public function test_order_cancel_is_scoped_to_owner(): void
    {
        [, $variant] = $this->createCatalog();
        $owner = $this->makeUser();
        $stranger = $this->makeUser();

        $orderId = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $owner->id,
            'status' => 'pending',
            'payment_status' => 'unpaid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ])->id;

        OrderItem::create([
            'order_id' => $orderId,
            'product_variant_id' => $variant->id,
            'product_name_snapshot' => 'Batik Klasik',
            'variant_size_snapshot' => 'L',
            'sku_snapshot' => $variant->sku,
            'price' => 150000,
            'quantity' => 1,
            'subtotal' => 150000,
        ]);

        $this->withToken($this->tokenFor($stranger))
            ->postJson("/api/orders/{$orderId}/cancel")
            ->assertNotFound();

        $this->assertSame('pending', Order::find($orderId)->status);
    }

    public function test_review_delete_is_denied_for_non_owner_non_admin(): void
    {
        $owner = $this->makeUser();
        $stranger = $this->makeUser();

        $review = ProductReview::create([
            'user_id' => $owner->id,
            'product_id' => $this->createCatalog()[0]->id,
            'rating' => 5,
            'comment' => 'Bagus sekali',
        ]);

        $this->withToken($this->tokenFor($stranger))
            ->deleteJson("/api/reviews/{$review->id}")
            ->assertForbidden();

        $this->assertDatabaseHas('product_reviews', ['id' => $review->id]);
    }

    /**
     * Klien nyata (mis. fetch()/curl) bisa saja tidak mengirim header
     * "Accept: application/json". Endpoint API wajib tetap membalas 401 JSON,
     * bukan 500 "Route [login] not defined" karena aplikasi ini tidak punya
     * route bernama "login" untuk dialihkan (redirect).
     */
    public function test_unauthenticated_api_request_without_json_accept_header_returns_401(): void
    {
        // get() sengaja dipakai (bukan getJson) agar tidak mengirim Accept: application/json.
        $response = $this->get('/api/me');

        $response->assertStatus(401);
        $response->assertJsonPath('status', 'error');

        $body = $response->getContent();
        $this->assertStringNotContainsString('Route [login] not defined', $body);
        $this->assertStringNotContainsString('RouteNotFoundException', $body);
    }
}
