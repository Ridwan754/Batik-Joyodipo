<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use App\Models\UserAddress;
use App\Models\Voucher;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Alur utama endpoint API yang dipakai frontend:
 * autentikasi, profil, katalog, alamat, keranjang, checkout, pesanan,
 * voucher, ulasan, pengiriman, dan dashboard.
 */
class ApiEndpointFlowTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(string $role = 'pelanggan'): User
    {
        return User::forceCreate([
            'name' => ucfirst($role),
            'email' => $role.'-'.bin2hex(random_bytes(6)).'@example.test',
            'password' => 'secret123',
            'role' => $role,
        ]);
    }

    private function tokenFor(User $user): string
    {
        $this->app['auth']->forgetGuards();

        return $user->createToken('test')->plainTextToken;
    }

    /** @return array{0: Category, 1: Product, 2: ProductVariant} */
    private function createCatalog(int $stock = 5): array
    {
        $category = Category::create(['name' => 'Batik Pria', 'slug' => 'batik-pria']);
        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Klasik',
            'slug' => 'batik-klasik',
            'gender_type' => 'men',
            'is_active' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-'.bin2hex(random_bytes(4)),
            'size' => 'L',
            'price' => 150000,
            'stock' => $stock,
        ]);

        return [$category, $product, $variant];
    }

    private function addressPayload(array $overrides = []): array
    {
        return array_merge([
            'label_alamat' => 'Rumah',
            'nama_penerima' => 'Budi',
            'nomor_telepon' => '081234567890',
            'nama_provinsi' => 'DKI Jakarta',
            'nama_kota' => 'Jakarta',
            'nama_kecamatan' => 'Menteng',
            'kode_pos' => '10310',
            'alamat_lengkap' => 'Jl. Merdeka No. 1',
        ], $overrides);
    }

    // -----------------------------------------------------------------
    // Autentikasi & profil
    // -----------------------------------------------------------------

    public function test_register_login_me_and_logout_flow(): void
    {
        $this->postJson('/api/register', [
            'nama_pengguna' => 'Pelanggan Baru',
            'email' => 'pelanggan-baru@example.test',
            'kata_sandi' => 'rahasia123',
            'kata_sandi_confirmation' => 'rahasia123',
            'nomor_telepon' => '08111111111',
        ])->assertStatus(201)->assertJsonPath('success', true);

        $token = $this->postJson('/api/login', [
            'email' => 'pelanggan-baru@example.test',
            'kata_sandi' => 'rahasia123',
        ])
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('data.token_type', 'Bearer')
            ->json('data.token');

        $this->withToken($token)->getJson('/api/me')
            ->assertOk()
            ->assertJsonPath('data.email', 'pelanggan-baru@example.test');

        $this->withToken($token)->postJson('/api/logout')
            ->assertOk()
            ->assertJsonPath('success', true);

        // Reset guard karena dalam satu test guard masih menyimpan user hasil resolve.
        $this->app['auth']->forgetGuards();

        // Token sudah dicabut.
        $this->withToken($token)->getJson('/api/me')->assertStatus(401);
    }

    public function test_login_with_wrong_password_is_rejected(): void
    {
        $user = $this->makeUser();

        $this->postJson('/api/login', [
            'email' => $user->email,
            'kata_sandi' => 'sandi-salah',
        ])->assertStatus(401)->assertJsonPath('success', false);
    }

    public function test_protected_endpoints_require_authentication(): void
    {
        // Test ini sengaja tidak pernah mengirim token sama sekali,
        // sehingga hasilnya tidak dipengaruhi caching guard antar request.
        foreach ([
            '/api/me',
            '/api/cart',
            '/api/orders/me',
            '/api/addresses',
            '/api/wishlist',
            '/api/vouchers/available',
            '/api/dashboard',
            '/api/admin/products',
        ] as $uri) {
            $this->getJson($uri)->assertStatus(401);
        }

        foreach ([
            '/api/shipping/cost',
            '/api/vouchers/validate',
            '/api/cart/items',
            '/api/orders',
        ] as $uri) {
            $this->postJson($uri, [])->assertStatus(401);
        }

        $this->putJson('/api/profile', [])->assertStatus(401);
    }

    public function test_profile_can_update_name_phone_and_password(): void
    {
        $user = $this->makeUser();
        $token = $this->tokenFor($user);

        $this->withToken($token)->putJson('/api/profile', [
            'nama_pengguna' => 'Nama Diganti',
            'nomor_telepon' => '08999999999',
            'kata_sandi_lama' => 'salah',
            'kata_sandi' => 'barusandi123',
            'kata_sandi_confirmation' => 'barusandi123',
        ])->assertStatus(400)->assertJsonPath('message', 'Kata sandi lama tidak sesuai.');

        $this->withToken($token)->putJson('/api/profile', [
            'nama_pengguna' => 'Nama Diganti',
            'nomor_telepon' => '08999999999',
            'kata_sandi_lama' => 'secret123',
            'kata_sandi' => 'barusandi123',
            'kata_sandi_confirmation' => 'barusandi123',
        ])->assertOk()->assertJsonPath('data.name', 'Nama Diganti');

        // Kata sandi lama sudah tidak berlaku; yang baru bisa dipakai login.
        $this->postJson('/api/login', [
            'email' => $user->email,
            'kata_sandi' => 'secret123',
        ])->assertStatus(401);

        $this->postJson('/api/login', [
            'email' => $user->email,
            'kata_sandi' => 'barusandi123',
        ])->assertOk();
    }

    // -----------------------------------------------------------------
    // Katalog publik
    // -----------------------------------------------------------------

    public function test_public_catalog_endpoints_respond(): void
    {
        [$category, $product] = $this->createCatalog();

        $this->getJson('/api/home')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->assertJsonPath('data.categories.0.slug', $category->slug)
            ->assertJsonPath('data.latest_products.0.slug', $product->slug);

        $this->getJson('/api/categories')->assertOk()->assertJsonPath('status', 'success');

        $this->getJson("/api/categories/{$category->id}")
            ->assertOk()
            ->assertJsonPath('data.id', $category->id);

        $this->getJson('/api/products')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->assertJsonPath('data.0.slug', $product->slug);

        $this->getJson("/api/products/{$product->slug}")
            ->assertOk()
            ->assertJsonPath('data.slug', $product->slug)
            ->assertJsonPath('data.variants.0.size', 'L');

        $this->getJson('/api/products/search?q=Klasik')
            ->assertOk()
            ->assertJsonPath('status', 'success');

        // Detail produk yang tidak ada -> 404 konsisten
        $this->getJson('/api/products/tidak-ada')->assertNotFound();
    }

    public function test_product_reviews_endpoint_returns_rating_summary(): void
    {
        [, $product] = $this->createCatalog();

        $this->getJson("/api/products/{$product->slug}/reviews")
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('data.total_reviews', 0);

        $this->assertEquals(0.0, $this->getJson("/api/products/{$product->slug}/reviews")->json('data.average_rating'));
    }

    // -----------------------------------------------------------------
    // Alamat
    // -----------------------------------------------------------------

    public function test_address_crud_and_set_primary(): void
    {
        $user = $this->makeUser();
        $token = $this->tokenFor($user);

        // Alamat pertama otomatis menjadi alamat utama.
        $firstId = $this->withToken($token)->postJson('/api/addresses', $this->addressPayload())
            ->assertStatus(201)->json('data.id');

        $secondId = $this->withToken($token)->postJson(
            '/api/addresses',
            $this->addressPayload([
                'label_alamat' => 'Kantor',
                'alamat_lengkap' => 'Jl. Sudirman No. 2',
            ])
        )->assertStatus(201)->json('data.id');

        // Menambah alamat kedua tidak mengambil status utama.
        $this->assertTrue(
            (bool) UserAddress::find($firstId)->is_primary
        );

        $this->withToken($token)->putJson("/api/addresses/{$secondId}/set-primary")
            ->assertOk()
            ->assertJsonPath('data.is_primary', true);

        $this->assertFalse((bool) UserAddress::find($firstId)->is_primary);
        $this->assertTrue((bool) UserAddress::find($secondId)->is_primary);

        // Daftar alamat memuat milik sendiri saja.
        $this->withToken($token)->getJson('/api/addresses')
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('data.0.id', $secondId);

        $this->withToken($token)->deleteJson("/api/addresses/{$firstId}")->assertOk();
        $this->assertDatabaseMissing('user_addresses', ['id' => $firstId]);
    }

    // -----------------------------------------------------------------
    // Keranjang, wishlist & checkout
    // -----------------------------------------------------------------

    public function test_cart_add_update_and_clear_flow(): void
    {
        [, , $variant] = $this->createCatalog(stock: 5);
        $token = $this->tokenFor($this->makeUser());

        // Kuantitas melebihi stok ditolak oleh validasi aturan bisnis.
        $this->withToken($token)->postJson('/api/cart/items', [
            'product_variant_id' => $variant->id,
            'quantity' => 99,
        ])->assertStatus(422);

        $this->withToken($token)->postJson('/api/cart/items', [
            'product_variant_id' => $variant->id,
            'quantity' => 2,
        ])->assertStatus(201)->assertJsonPath('status', 'success');

        $itemId = $this->withToken($token)->getJson('/api/cart')
            ->assertOk()->json('data.items.0.id');

        $this->withToken($token)->putJson("/api/cart/items/{$itemId}", ['quantity' => 3])
            ->assertOk()
            ->assertJsonPath('data.quantity', 3);

        $this->withToken($token)->deleteJson('/api/cart')->assertOk();

        $this->withToken($token)->getJson('/api/cart')
            ->assertOk()
            ->assertJsonCount(0, 'data.items');
    }

    public function test_wishlist_add_list_and_remove_flow(): void
    {
        [$product] = $this->createCatalog();
        $token = $this->tokenFor($this->makeUser());

        $this->withToken($token)->postJson('/api/wishlist', ['product_id' => $product->id])
            ->assertStatus(201);

        // Menambah dua kali tidak membuat duplikat.
        $this->withToken($token)->postJson('/api/wishlist', ['product_id' => $product->id])
            ->assertStatus(201);

        $this->withToken($token)->getJson('/api/wishlist')
            ->assertOk()
            ->assertJsonCount(1, 'data');

        $wishlistId = $this->withToken($token)->getJson('/api/wishlist')->json('data.0.id');

        $this->withToken($token)->deleteJson("/api/wishlist/{$wishlistId}")->assertOk();

        $this->withToken($token)->getJson('/api/wishlist')->assertJsonCount(0, 'data');
    }

    public function test_checkout_from_cart_creates_order_and_restores_no_stock(): void
    {
        [, , $variant] = $this->createCatalog(stock: 5);
        $user = $this->makeUser();
        $token = $this->tokenFor($user);

        $this->withToken($token)->postJson('/api/cart/items', [
            'product_variant_id' => $variant->id,
            'quantity' => 2,
        ])->assertStatus(201);

        $this->withToken($token)->postJson('/api/orders/from-cart', [
            'shipping_cost' => 10000,
        ])->assertStatus(201)->assertJsonPath('status', 'success');

        // Stok terpotong dan keranjang dikosongkan.
        $this->assertSame(3, $variant->fresh()->stock);
        $this->withToken($token)->getJson('/api/cart')->assertJsonCount(0, 'data.items');

        // Pesanan tampil di daftar milik sendiri.
        $orders = $this->withToken($token)->getJson('/api/orders/me')
            ->assertOk()->json('data');
        $this->assertCount(1, $orders);
        $this->assertSame('pending', $orders[0]['status']);

        $this->assertSame(1, Order::count());
    }

    public function test_shipping_cost_rejects_invalid_payload(): void
    {
        $token = $this->tokenFor($this->makeUser());

        // Payload tidak lengkap divalidasi sebelum memanggil layanan eksternal.
        $this->withToken($token)->postJson('/api/shipping/cost', [])
            ->assertStatus(422);

        $this->withToken($token)->postJson('/api/shipping/cost', [
            'destination_city_id' => '151',
            'weight_g' => 1000,
            'courier' => 'sicepat',
        ])->assertStatus(422);
    }

    // -----------------------------------------------------------------
    // Voucher
    // -----------------------------------------------------------------

    public function test_customer_voucher_available_and_validate(): void
    {
        $token = $this->tokenFor($this->makeUser());

        Voucher::create([
            'code' => 'HEMAT10',
            'name' => 'Diskon 10%',
            'type' => 'percentage',
            'discount_amount' => 10,
            'min_order_amount' => 50000,
            'is_active' => true,
        ]);

        $this->withToken($token)->getJson('/api/vouchers/available')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->assertJsonPath('data.0.code', 'HEMAT10');

        $this->withToken($token)->postJson('/api/vouchers/validate', [
            'code' => 'HEMAT10',
            'subtotal' => 100000,
        ])->assertOk()->assertJsonPath('data.discount_amount', 10000);

        // Kode tidak valid ditolak.
        $this->withToken($token)->postJson('/api/vouchers/validate', [
            'code' => 'TIDAK-ADA',
            'subtotal' => 100000,
        ])->assertStatus(404);

        // Di bawah minimum belanja ditolak.
        $this->withToken($token)->postJson('/api/vouchers/validate', [
            'code' => 'HEMAT10',
            'subtotal' => 10000,
        ])->assertStatus(400);

        // Voucher customer wajib login. flushHeaders menghapus token dari request
        // berikutnya, dan forgetGuards mereset user yang masih di-cache guard
        // (keduanya bersifat persisten selama satu test berjalan).
        $this->flushHeaders();
        $this->app['auth']->forgetGuards();

        $this->postJson('/api/vouchers/validate', [
            'code' => 'HEMAT10',
            'subtotal' => 100000,
        ])->assertStatus(401);
    }

    // -----------------------------------------------------------------
    // Ulasan
    // -----------------------------------------------------------------

    public function test_review_can_be_created_for_completed_order_only(): void
    {
        [$category, $product, $variant] = $this->createCatalog();
        $user = $this->makeUser();
        $token = $this->tokenFor($user);

        $orderId = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $user->id,
            'status' => 'pending',
            'payment_status' => 'unpaid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ])->id;

        OrderItem::create([
            'order_id' => $orderId,
            'product_variant_id' => $variant->id,
            'product_name_snapshot' => 'Batik Klasik',
            'variant_size_snapshot' => 'L',
            'sku_snapshot' => $variant->sku,
            'price' => 150000,
            'quantity' => 1,
            'subtotal' => 150000,
        ]);

        // Pesanan belum selesai -> ditolak.
        $this->withToken($token)->postJson("/api/orders/{$orderId}/reviews", [
            'product_id' => $product->id,
            'rating' => 5,
            'comment' => 'Mantap',
        ])->assertStatus(400);

        Order::find($orderId)->update(['status' => 'completed']);

        // Produk yang tidak dipesan pada pesanan ini -> ditolak.
        $otherProduct = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Lain',
            'slug' => 'batik-lain',
            'is_active' => true,
        ]);
        $this->withToken($token)->postJson("/api/orders/{$orderId}/reviews", [
            'product_id' => $otherProduct->id,
            'rating' => 5,
        ])->assertStatus(400);

        $this->withToken($token)->postJson("/api/orders/{$orderId}/reviews", [
            'product_id' => $product->id,
            'rating' => 5,
            'comment' => 'Mantap',
        ])->assertStatus(201)->assertJsonPath('success', true);

        // Ulasan tampil publik beserta rata-ratanya.
        $publicReviews = $this->getJson("/api/products/{$product->slug}/reviews")->assertOk();
        $publicReviews->assertJsonPath('data.total_reviews', 1);
        $this->assertEquals(5.0, $publicReviews->json('data.average_rating'));

        // Ulasan milik orang lain tidak bisa dihapus oleh user biasa.
        $stranger = $this->makeUser();
        $reviewId = $this->getJson("/api/products/{$product->slug}/reviews")->json('data.reviews.0.id');
        $this->withToken($this->tokenFor($stranger))
            ->deleteJson("/api/reviews/{$reviewId}")
            ->assertForbidden();
    }

    // -----------------------------------------------------------------
    // Otorisasi admin
    // -----------------------------------------------------------------

    public function test_dashboard_requires_admin_role(): void
    {
        $customer = $this->makeUser();
        $admin = $this->makeUser('admin');

        $this->withToken($this->tokenFor($customer))->getJson('/api/dashboard')->assertForbidden();

        $this->withToken($this->tokenFor($admin))->getJson('/api/dashboard')
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonStructure([
                'data' => [
                    'total_products',
                    'total_customers',
                    'total_orders',
                    'total_revenue',
                    'orders_by_status',
                    'recent_orders',
                ],
            ]);
    }

    public function test_admin_order_list_and_status_endpoint_are_admin_only(): void
    {
        $customer = $this->makeUser();
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        // Admin bisa memasukkan resi sekaligus menandai pesanan sebagai shipped.
        [, , $variant] = $this->createCatalog();
        $owner = $this->makeUser();
        $orderId = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $owner->id,
            'status' => 'processing',
            'payment_status' => 'paid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ])->id;

        $this->withToken($token)->getJson('/api/orders')->assertOk()->assertJsonPath('status', 'success');

        $this->withToken($token)->putJson("/api/orders/{$orderId}/shipment", [
            'courier_code' => 'jne',
            'courier_service' => 'REG',
            'tracking_number' => 'JNE-001',
            'recipient_name' => 'Budi',
            'phone_number' => '081234567890',
            'full_address' => 'Jl. Merdeka No. 1',
        ])->assertOk();

        $this->assertSame('shipped', Order::find($orderId)->status);

        $this->withToken($this->tokenFor($customer))->getJson('/api/orders')->assertForbidden();
    }
}
