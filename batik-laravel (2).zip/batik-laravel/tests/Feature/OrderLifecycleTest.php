<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Audit siklus hidup pesanan & integritas data:
 * pengembalian stok, transisi status, status final, dan sinkronisasi Midtrans.
 */
class OrderLifecycleTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(string $role = 'pelanggan'): User
    {
        // 'role' bukan mass-assignable lagi (mencegah eskalasi hak akses),
        // sehingga peran ditetapkan lewat forceCreate khusus untuk pengujian.
        return User::forceCreate([
            'name' => ucfirst($role),
            'email' => $role.'-'.bin2hex(random_bytes(6)).'@example.test',
            'password' => 'secret123',
            'role' => $role,
        ]);
    }

    private function tokenFor(User $user): string
    {
        $this->app['auth']->forgetGuards();

        return $user->createToken('test')->plainTextToken;
    }

    /** @return array{0: Product, 1: ProductVariant} */
    private function createCatalog(int $stock = 5): array
    {
        $category = Category::create(['name' => 'Batik Pria', 'slug' => 'batik-pria']);
        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Batik Klasik',
            'slug' => 'batik-klasik',
            'gender_type' => 'men',
            'is_active' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'SKU-'.bin2hex(random_bytes(4)),
            'size' => 'L',
            'price' => 150000,
            'stock' => $stock,
        ]);

        return [$product, $variant];
    }

    private function createOrder(User $user, ProductVariant $variant, string $status = 'pending'): Order
    {
        $order = Order::create([
            'order_number' => 'ORD-'.strtoupper(uniqid()),
            'user_id' => $user->id,
            'status' => $status,
            'payment_status' => 'unpaid',
            'subtotal_amount' => 150000,
            'shipping_cost' => 10000,
            'grand_total' => 160000,
        ]);

        OrderItem::create([
            'order_id' => $order->id,
            'product_variant_id' => $variant->id,
            'product_name_snapshot' => 'Batik Klasik',
            'variant_size_snapshot' => 'L',
            'sku_snapshot' => $variant->sku,
            'price' => 150000,
            'quantity' => 1,
            'subtotal' => 150000,
        ]);

        return $order;
    }

    public function test_category_with_products_cannot_be_deleted_but_empty_category_can(): void
    {
        [$product] = $this->createCatalog();
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        $this->withToken($token)
            ->deleteJson("/api/categories/{$product->category_id}")
            ->assertStatus(400)
            ->assertJsonPath('status', 'error');
        $this->assertDatabaseHas('categories', ['id' => $product->category_id]);
        $this->assertDatabaseHas('products', ['id' => $product->id]);

        $empty = Category::create(['name' => 'Kosong', 'slug' => 'kosong']);
        $this->withToken($token)->deleteJson("/api/categories/{$empty->id}")->assertOk();
        $this->assertDatabaseMissing('categories', ['id' => $empty->id]);
    }

    public function test_admin_cancel_restores_stock_and_reactivation_reserves_it_again(): void
    {
        [$product, $variant] = $this->createCatalog(stock: 5);
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant);
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        // Anggap stok sudah terpotong 1 saat checkout
        $variant->decrement('stock', 1);
        $this->assertSame(4, $variant->fresh()->stock);

        // Batalkan -> stok kembali
        $this->withToken($token)
            ->patchJson("/api/orders/{$order->id}/status", ['status' => 'cancelled'])
            ->assertOk();
        $this->assertSame(5, $variant->fresh()->stock);

        // Aktifkan kembali -> stok dipotong lagi
        $this->withToken($token)
            ->patchJson("/api/orders/{$order->id}/status", ['status' => 'processing'])
            ->assertOk();
        $this->assertSame(4, $variant->fresh()->stock);
        $this->assertSame('processing', $order->fresh()->status);
    }

    public function test_reactivation_is_rejected_when_stock_is_insufficient(): void
    {
        [$product, $variant] = $this->createCatalog(stock: 1);
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant, status: 'cancelled');
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        // Stok sedang habis; pembatalan sebelumnya sudah mengembalikan stok,
        // lalu stok diambil pembeli lain.
        $variant->update(['stock' => 0]);

        $this->withToken($token)
            ->patchJson("/api/orders/{$order->id}/status", ['status' => 'processing'])
            ->assertStatus(400);

        $this->assertSame('cancelled', $order->fresh()->status);
        $this->assertSame(0, $variant->fresh()->stock);
    }

    public function test_completed_order_cannot_change_status(): void
    {
        [$product, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant, status: 'completed');
        $admin = $this->makeUser('admin');
        $token = $this->tokenFor($admin);

        $this->withToken($token)
            ->patchJson("/api/orders/{$order->id}/status", ['status' => 'processing'])
            ->assertStatus(400);

        $this->assertSame('completed', $order->fresh()->status);
    }

    public function test_midtrans_settlement_marks_order_paid_and_processing(): void
    {
        [, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant);

        $order->applyMidtransStatus('settlement');

        $order->refresh();
        $this->assertSame('paid', $order->payment_status);
        $this->assertSame('processing', $order->status);
    }

    public function test_midtrans_does_not_downgrade_a_shipped_order(): void
    {
        [, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant, status: 'shipped');

        // Notifikasi settlement terlambat: pembayaran ditandai paid,
        // tetapi status pengiriman tidak boleh turun kembali ke processing.
        $order->applyMidtransStatus('settlement');

        $order->refresh();
        $this->assertSame('paid', $order->payment_status);
        $this->assertSame('shipped', $order->status);
    }

    public function test_midtrans_expire_cancels_order_and_restores_stock(): void
    {
        [, $variant] = $this->createCatalog(stock: 5);
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant);

        $variant->decrement('stock', 1);
        $this->assertSame(4, $variant->fresh()->stock);

        $order->applyMidtransStatus('expire');

        $order->refresh();
        $this->assertSame('cancelled', $order->status);
        $this->assertSame('expired', $order->payment_status);
        $this->assertSame(5, $variant->fresh()->stock);

        // Notifikasi ganda tidak mengembalikan stok dua kali
        $order->applyMidtransStatus('expire');
        $this->assertSame(5, $variant->fresh()->stock);
    }

    public function test_midtrans_does_not_cancel_a_shipped_order(): void
    {
        [, $variant] = $this->createCatalog(stock: 5);
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant, status: 'shipped');

        $order->applyMidtransStatus('deny');

        $order->refresh();
        $this->assertSame('shipped', $order->status);
        $this->assertSame('failed', $order->payment_status);
        $this->assertSame(5, $variant->fresh()->stock);
    }

    public function test_midtrans_unknown_status_is_a_noop(): void
    {
        [, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant);

        $order->applyMidtransStatus('refund');

        $order->refresh();
        $this->assertSame('pending', $order->status);
        $this->assertSame('unpaid', $order->payment_status);
    }

    public function test_webhook_rejects_notification_without_signature(): void
    {
        $this->postJson('/api/payments/webhook', [
            'order_id' => 'ORD-ABC',
            'status_code' => '200',
            'gross_amount' => '160000.00',
            'transaction_status' => 'settlement',
        ])->assertStatus(400)->assertJsonPath('status', 'error');
    }

    public function test_webhook_rejects_notification_with_invalid_signature(): void
    {
        $this->postJson('/api/payments/webhook', [
            'order_id' => 'ORD-ABC',
            'status_code' => '200',
            'gross_amount' => '160000.00',
            'signature_key' => 'not-a-valid-signature',
            'transaction_status' => 'settlement',
        ])->assertStatus(400)->assertJsonPath('status', 'error');
    }

    public function test_wildcard_routes_do_not_shadow_specific_routes(): void
    {
        [$product, $variant] = $this->createCatalog();
        $customer = $this->makeUser();
        $order = $this->createOrder($customer, $variant);

        // /products/search harus menang atas /products/{slug}
        $this->getJson('/api/products/search?q=Klasik')
            ->assertOk()
            ->assertJsonPath('status', 'success');

        // /orders/me harus menang atas /orders/{id}
        $this->withToken($this->tokenFor($customer))
            ->getJson('/api/orders/me')
            ->assertOk()
            ->assertJsonPath('status', 'success')
            ->assertJsonFragment(['id' => $order->id]);
    }
}
